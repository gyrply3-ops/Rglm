-- RGLM research terminal schema. Rows are unowned (no user_id): this app has no accounts.
-- Market cache, universe metadata, and scan snapshots only. Never store API tokens.

create table if not exists symbols (
  ticker text not null,
  exchange text not null,
  company text,
  country text,
  currency text,
  instrument_type text,
  isin text,
  classification_status text not null default 'UNKNOWN',
  rejection_reason text,
  data_source text,
  retrieved_at timestamptz,
  primary key (ticker, exchange)
);

create table if not exists index_members (
  index_code text not null,
  ticker text not null,
  exchange text,
  company text,
  membership_status text not null default 'CURRENT',
  source text,
  universe_kind text not null default 'CURRENT_CONSTITUENT',
  retrieved_at timestamptz,
  primary key (index_code, ticker)
);

create table if not exists daily_bars (
  ticker text not null,
  exchange text not null,
  bars_json text not null,
  first_date text,
  last_date text,
  bar_count integer,
  data_source text,
  data_version text,
  price_basis text,
  retrieved_at timestamptz,
  validation_status text,
  primary key (ticker, exchange)
);

create index if not exists daily_bars_last_date_idx on daily_bars (last_date);

create table if not exists scan_runs (
  id text primary key,
  strategy_version text not null,
  status text not null,
  reason_code text,
  reason_text text,
  data_snapshot_id text,
  coverage_status text,
  data_status text,
  provider text,
  market_regime text,
  volatility_stress boolean,
  latest_session text,
  universe_discovered integer,
  universe_eligible integer,
  result_json text not null,
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists scan_runs_created_at_idx on scan_runs (created_at desc);

create table if not exists scan_candidates (
  scan_id text not null,
  ticker text not null,
  company text,
  direction text,
  score double precision,
  passed_hard_gates boolean,
  reject_gates text,
  score_breakdown text,
  rank integer,
  is_winner boolean not null default false,
  primary key (scan_id, ticker)
);

create index if not exists scan_candidates_scan_id_idx on scan_candidates (scan_id);

create table if not exists provider_events (
  id serial primary key,
  event_type text not null,
  message text,
  meta text,
  created_at timestamptz not null default now()
);

create table if not exists provider_budget (
  id integer primary key default 1,
  requests_used integer not null default 0,
  requests_failed integer not null default 0,
  bulk_requests integer not null default 0,
  retries integer not null default 0,
  last_request_at timestamptz,
  window_start timestamptz,
  window_count integer not null default 0,
  daily_date text,
  daily_count integer not null default 0,
  rate_limited boolean not null default false,
  remaining_hint integer
);
