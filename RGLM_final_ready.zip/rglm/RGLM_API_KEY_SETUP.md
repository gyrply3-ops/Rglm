# RGLM EODHD API key and endpoint

The RGLM app is already wired to a **server-side EODHD provider**. You do not need Grok to add the endpoint.

## What is already connected

- `getRglmStatus` is a server function that validates the EODHD key and probes SPY.
- `runRglmScan` is a server function that runs DEMO or LIVE RGLM.
- Both functions execute on the server, call `createProvider(...)`, and the EODHD token is never returned in the scan result.
- The provider supports the server environment variable `EODHD_API_TOKEN` and also accepts the key supplied by the in-app field for a session.

## What you do

1. Open the running RGLM app.
2. Paste your EODHD API key into **EODHD API Key**.
3. Press **Test connection**.
4. Wait for `CONNECTED`.
5. Press **Find RGLM trade** for a LIVE research scan.

The UI keeps the key only in `sessionStorage`, so it is not baked into source code and is cleared when the browser session is closed.

## Important

- Do **not** put the real key in source files, ZIPs, screenshots, logs, or chat messages.
- No one needs to receive your key in order to finish the integration.
- A public HTTPS deployment is still required for a real external URL; the code already contains the server-side endpoint handlers.
- If `EODHD_API_TOKEN` is set on the server, the app can use it as a server-side fallback even without an in-app key.
