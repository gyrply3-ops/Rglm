# RGLM local run

## Requirements
- Node.js 22+
- npm 10+
- Internet access during the first dependency installation

## Start

```bash
./startup.sh
```

or:

```bash
npm run dev
```

The project now automatically runs `npm ci` when `node_modules` is missing, using the checked-in `package-lock.json`.

## Verify

```bash
npm run typecheck
npm test
npm run build
```

If dependency installation fails with a DNS/registry error such as `ENOTFOUND registry.npmjs.org`, the code is not the cause; restore network access and rerun.

## EODHD

Set `EODHD_API_TOKEN` as a server-side environment variable. Do not commit a real token or expose it to client code.
