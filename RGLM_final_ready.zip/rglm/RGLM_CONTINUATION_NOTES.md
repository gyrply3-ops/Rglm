# RGLM v0.1 — continuation notes

This workspace continues the existing RGLM implementation. It does not contain a real EODHD API token.

## What was hardened

- Kept EODHD credentials server-only through `EODHD_API_TOKEN`.
- Separated EODHD HTTP-request/minute limits from API-call/day costs. Bulk requests cost API calls without consuming the same number of minute requests.
- Honoured `Retry-After` on HTTP 429 responses and treated HTTP 402 daily-limit exhaustion as a rate-limit condition.
- Parsed numeric usage fields returned as either numbers or strings by the EODHD User API.
- Used the provider's current rate-limit headers instead of relying only on a fixed minute-limit default.
- Limited SPY history requests to a finite lookback rather than requesting an unbounded history on every status/scan.
- Used 16:00 America/New_York as the regular-session completion boundary, avoiding a fixed-UTC assumption across daylight-saving transitions.
- Deduplicated eligible US tickers before counting/scanning coverage.
- Added bounded concurrent cache warming so repeated live scans can progressively build the required 3,000+ validated-history universe without falsely reporting complete coverage.
- Added diagnostics for daily API-call usage and minute-request headroom.

## Verification

The focused RGLM/provider test set passes: 48 tests, 0 failures.

A full workspace dependency install could not be completed in the build environment, so a full Vite production build was not re-run here. The live EODHD path also remains untested against a real account until `EODHD_API_TOKEN` is configured.

## Required secret

Set `EODHD_API_TOKEN` in the server-side environment/Secrets store. Do not put the token in source code, browser code, screenshots, logs, or chat messages.
