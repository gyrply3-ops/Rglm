import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Check,
  ChevronDown,
  Database,
  Info,
  Loader2,
  Shield,
  X,
} from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import { explainRglmScan, getRglmStatus, runRglmScan, type StatusPayload } from "@/lib/rglm-server";
import type { GateResult, RglmResult } from "@/lib/rglm/types";
import { cn } from "@/lib/utils";

function fmtPx(n: number | null | undefined, d = 2): string {
  if (n == null || !Number.isFinite(n)) return "—";
  return n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
}

function fmtPct(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "—";
  const sign = n > 0 ? "+" : "";
  return `${sign}${(n * 100).toFixed(2)}%`;
}

function fmtScore(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "—";
  return n.toFixed(1);
}

function Chip({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "long" | "short" | "warn" | "ok";
}) {
  const color =
    tone === "long"
      ? "text-long"
      : tone === "short"
        ? "text-short"
        : tone === "warn"
          ? "text-warn"
          : tone === "ok"
            ? "text-long"
            : "text-fg";
  return (
    <div className="min-w-0 rounded-md border border-border bg-surface px-3 py-2">
      <div className="text-[10px] font-medium uppercase tracking-[0.14em] text-subtle">{label}</div>
      <div className={cn("mt-1 truncate font-mono text-sm tabular-nums", color)}>{value}</div>
    </div>
  );
}

function Panel({
  title,
  children,
  defaultOpen = true,
}: {
  title: string;
  children: ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="overflow-hidden rounded-xl border border-border bg-surface">
      <button
        type="button"
        className="flex h-11 w-full items-center justify-between px-4 text-left"
        onClick={() => setOpen((v) => !v)}
      >
        <span className="text-xs font-medium uppercase tracking-[0.16em] text-muted">{title}</span>
        <ChevronDown className={cn("size-4 text-subtle transition-transform duration-150", open && "rotate-180")} />
      </button>
      {open ? <div className="border-t border-border px-4 py-4">{children}</div> : null}
    </section>
  );
}

function GateRow({ gate }: { gate: GateResult }) {
  return (
    <li className="flex items-start gap-3 py-2">
      <span
        className={cn(
          "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-sm border",
          gate.passed ? "border-long/40 text-long" : "border-short/40 text-short",
        )}
      >
        {gate.passed ? <Check className="size-3" /> : <X className="size-3" />}
      </span>
      <div className="min-w-0">
        <div className="font-mono text-xs uppercase tracking-wide text-fg">{gate.name}</div>
        <div className="text-sm text-muted">{gate.detail}</div>
      </div>
    </li>
  );
}

function ScoreBar({ label, value, max }: { label: string; value: number; max: number }) {
  const pct = max <= 0 ? 0 : Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3">
        <span className="text-xs uppercase tracking-wide text-muted">{label}</span>
        <span className="font-mono text-xs tabular-nums text-fg">
          {fmtScore(value)} / {max}
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-elevated">
        <div className="h-full rounded-full bg-accent" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function RglmTerminal() {
  const [status, setStatus] = useState<StatusPayload | null>(null);
  const [result, setResult] = useState<RglmResult | null>(null);
  const [phase, setPhase] = useState<"IDLE" | "STATUS" | "SCANNING" | "EXPLAINING">("STATUS");
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [explain, setExplain] = useState<string | null>(null);
  const [panel, setPanel] = useState<"checklist" | "score" | "stats" | "chart" | "explain">("checklist");
  const [eodhdApiKey, setEodhdApiKey] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const [testingApiKey, setTestingApiKey] = useState(false);

  useEffect(() => {
    let live = true;
    const sessionKey = window.sessionStorage.getItem("rglm.eodhdApiKey") ?? "";
    setEodhdApiKey(sessionKey);
    (async () => {
      try {
        const s = await getRglmStatus({ data: { eodhdApiKey: sessionKey || undefined } });
        if (!live) return;
        setStatus(s);
        if (s.lastScan) setResult(s.lastScan);
      } catch (e) {
        if (!live) return;
        setError(e instanceof Error ? e.message : "Status check failed.");
      } finally {
        if (live) setPhase("IDLE");
      }
    })();
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    if (phase !== "SCANNING") return;
    const t0 = Date.now();
    const id = setInterval(() => setElapsed(Math.floor((Date.now() - t0) / 1000)), 250);
    return () => clearInterval(id);
  }, [phase]);

  async function scan(mode: "LIVE" | "DEMO") {
    setError(null);
    setExplain(null);
    setPhase("SCANNING");
    setElapsed(0);
    try {
      const r = await runRglmScan({ data: { mode, eodhdApiKey: eodhdApiKey.trim() || undefined } });
      setResult(r);
      const s = await getRglmStatus({ data: { eodhdApiKey: eodhdApiKey.trim() || undefined } });
      setStatus(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Scan failed.");
    } finally {
      setPhase("IDLE");
    }
  }

  async function onExplain() {
    if (!result) return;
    setPhase("EXPLAINING");
    setError(null);
    try {
      const out = await explainRglmScan({ data: { scanId: result.dataSnapshotId } });
      if (out.ok) {
        setExplain(out.text);
        setPanel("explain");
      } else setError(out.error);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Explain failed.");
    } finally {
      setPhase("IDLE");
    }
  }

  const regime = result?.marketRegime ?? "—";
  const vol = result?.volatilityState ?? "—";
  const coverage = result?.coverageStatus ?? "UNKNOWN";
  const api = status?.apiStatus ?? "NOT_CONFIGURED";

  const chartData = useMemo(() => result?.chart ?? [], [result]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      {result?.dataStatus === "DEMO" ? (
        <div className="border-b border-warn/30 bg-elevated px-4 py-2 text-center font-mono text-[11px] uppercase tracking-[0.2em] text-warn">
          Demo data — synthetic bars, not live EODHD
        </div>
      ) : null}

      <header className="border-b border-border px-4 py-4 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
              Daily system · Research / paper only
            </div>
            <h1 className="mt-1 font-sans text-2xl font-semibold tracking-tight sm:text-3xl">RGLM Scanner</h1>
            <p className="mt-1 font-mono text-xs text-muted">RGLM v0.1 · Regime-Gated Adaptive Momentum</p>
          </div>
          <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-subtle">
            <span className="rounded-sm border border-border px-2 py-1">No brokerage</span>
            <span className="rounded-sm border border-border px-2 py-1">No orders</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-5 sm:px-6 sm:py-8">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
          <Chip
            label="Market regime"
            value={String(regime)}
            tone={regime === "TREND_UP" ? "long" : regime === "TREND_DOWN" ? "short" : regime === "TRANSITION" ? "warn" : "neutral"}
          />
          <Chip label="SPY" value={result?.spy.lastDate ? fmtPx(result.spy.close) : "—"} />
          <Chip
            label="Volatility"
            value={String(vol).replaceAll("_", " ")}
            tone={vol === "ACCEPTABLE" ? "ok" : vol === "VOLATILITY_STRESS" ? "warn" : "neutral"}
          />
          <Chip
            label="Data provider"
            value={api.replaceAll("_", " ")}
            tone={api === "CONNECTED" ? "ok" : api === "NOT_CONFIGURED" ? "warn" : "short"}
          />
          <Chip
            label="Scan coverage"
            value={coverage}
            tone={coverage === "COMPLETE" ? "ok" : coverage === "INSUFFICIENT" ? "warn" : "neutral"}
          />
          <Chip label="Data status" value={result?.dataStatus ?? (status?.tokenConfigured ? "READY" : "NOT CONFIGURED")} />
        </div>

        <section className="mt-6 rounded-xl border border-border bg-surface p-4 sm:p-5">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
            <div className="min-w-0 flex-1">
              <label htmlFor="eodhd-api-key" className="text-xs font-medium uppercase tracking-[0.16em] text-muted">
                EODHD API Key
              </label>
              <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                <input
                  id="eodhd-api-key"
                  type={showApiKey ? "text" : "password"}
                  autoComplete="off"
                  spellCheck={false}
                  value={eodhdApiKey}
                  onChange={(e) => setEodhdApiKey(e.target.value)}
                  placeholder="Paste your EODHD API key"
                  className="h-11 min-w-0 flex-1 rounded-md border border-border bg-bg px-3 font-mono text-sm text-fg outline-none placeholder:text-subtle focus:border-accent"
                />
                <Button
                  type="button"
                  variant="secondary"
                  className="h-11"
                  onClick={() => {
                    if (eodhdApiKey.trim()) window.sessionStorage.setItem("rglm.eodhdApiKey", eodhdApiKey.trim());
                    else window.sessionStorage.removeItem("rglm.eodhdApiKey");
                    setShowApiKey((v) => !v);
                  }}
                >
                  {showApiKey ? "Hide key" : "Show key"}
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  className="h-11"
                  disabled={testingApiKey}
                  onClick={async () => {
                    setTestingApiKey(true);
                    setError(null);
                    try {
                      const key = eodhdApiKey.trim();
                      if (key) window.sessionStorage.setItem("rglm.eodhdApiKey", key);
                      else window.sessionStorage.removeItem("rglm.eodhdApiKey");
                      const s = await getRglmStatus({ data: { eodhdApiKey: key || undefined } });
                      setStatus(s);
                    } catch (e) {
                      setError(e instanceof Error ? e.message : "EODHD connection test failed.");
                    } finally {
                      setTestingApiKey(false);
                    }
                  }}
                >
                  {testingApiKey ? <Loader2 className="animate-spin" /> : <Database />}
                  Test connection
                </Button>
              </div>
              <p className="mt-2 text-xs text-subtle">
                The key is kept only for this browser session and sent only to the server for EODHD requests. It is never displayed in scan results or logs.
              </p>
            </div>
            <button
              type="button"
              className="text-xs uppercase tracking-wider text-subtle underline-offset-4 hover:text-fg hover:underline"
              onClick={() => {
                window.sessionStorage.removeItem("rglm.eodhdApiKey");
                setEodhdApiKey("");
                setStatus(null);
              }}
            >
              Clear key
            </button>
          </div>
        </section>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button
            className="h-12 min-h-12 w-full sm:w-auto sm:min-w-56"
            disabled={phase === "SCANNING"}
            onClick={() => scan("LIVE")}
          >
            {phase === "SCANNING" ? <Loader2 className="animate-spin" /> : <Activity />}
            Find RGLM trade
          </Button>
          <Button
            variant="demo"
            className="h-12 min-h-12 w-full sm:w-auto"
            disabled={phase === "SCANNING"}
            onClick={() => scan("DEMO")}
          >
            Run demo research scan
          </Button>
          {phase === "SCANNING" ? (
            <p className="font-mono text-xs text-muted">
              Running RGLM pipeline… {elapsed}s elapsed. Progress is real work, not an animation.
            </p>
          ) : (
            <p className="text-sm text-muted">
              {status?.message ?? "Checking data provider…"} Latest completed session:{" "}
              <span className="font-mono text-fg">{status?.latestProbeSession ?? status?.expectedSession ?? "—"}</span>
            </p>
          )}
        </div>

        {error ? (
          <div className="mt-4 flex items-start gap-2 rounded-lg border border-short/40 bg-elevated px-3 py-3 text-sm text-short">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}

        <div className="mt-8 rounded-xl border border-border bg-surface p-5 sm:p-8">
          {!result ? (
            <div className="text-center">
              <div className="text-[11px] uppercase tracking-[0.2em] text-subtle">Initial</div>
              <h2 className="mt-2 text-2xl font-semibold tracking-tight">No scan yet</h2>
              <p className="mx-auto mt-2 max-w-lg text-sm text-muted">
                A NO TRADE result is a valid successful outcome. The engine will not invent coverage or force a signal.
              </p>
            </div>
          ) : (
            <div className="text-center">
              <div className="text-[11px] uppercase tracking-[0.2em] text-subtle">{result.reasonCode.replaceAll("_", " ")}</div>
              <h2
                className={cn(
                  "mt-2 text-3xl font-semibold tracking-tight sm:text-4xl",
                  result.status === "TRADE" ? "text-fg" : "text-muted",
                )}
              >
                {result.status === "TRADE" ? "TRADE — RESEARCH SIGNAL" : "NO TRADE"}
              </h2>
              <p className="mx-auto mt-3 max-w-2xl text-sm text-muted">{result.reasonText}</p>
              <p className="mt-3 font-mono text-[11px] text-subtle">
                {result.dataSnapshotId} · {result.latestCompletedSession ?? "—"} · {result.strategyVersion}
              </p>
            </div>
          )}
        </div>

        {result?.winner ? (
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <section className="rounded-xl border border-border bg-surface p-5">
              <h3 className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Research signal</h3>
              <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <div className="text-2xl font-semibold tracking-tight">{result.winner.ticker}</div>
                  <div className="text-sm text-muted">{result.winner.company}</div>
                </div>
                <div
                  className={cn(
                    "rounded-md border px-2 py-1 font-mono text-xs",
                    result.winner.direction === "LONG" ? "border-long/40 text-long" : "border-short/40 text-short",
                  )}
                >
                  {result.winner.direction}
                </div>
              </div>
              <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">RGLM score</dt>
                  <dd className="font-mono tabular-nums">{fmtScore(result.winner.score)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Current price</dt>
                  <dd className="font-mono tabular-nums">{fmtPx(result.winner.currentPrice)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Reference entry — research price</dt>
                  <dd className="font-mono tabular-nums">{fmtPx(result.winner.referenceEntry)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Research stop</dt>
                  <dd className="font-mono tabular-nums">{fmtPx(result.winner.stop)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Research target — 3R</dt>
                  <dd className="font-mono tabular-nums">{fmtPx(result.winner.target3R)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Theoretical research size</dt>
                  <dd className="font-mono tabular-nums">
                    {fmtPx(result.winner.theoreticalQuantity, 2)} sh · ${fmtPx(result.winner.theoreticalPositionSize, 0)}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Risk budget</dt>
                  <dd className="font-mono tabular-nums">${fmtPx(result.winner.theoreticalRiskBudget, 0)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-subtle">Relative excess 63D</dt>
                  <dd className="font-mono tabular-nums">{fmtPct(result.winner.excess63)}</dd>
                </div>
              </dl>
              <p className="mt-4 text-xs text-subtle">{result.researchDisclaimer}</p>
            </section>

            <section className="rounded-xl border border-border bg-surface p-5">
              <h3 className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Score breakdown</h3>
              {result.scoreBreakdown ? (
                <div className="mt-4 space-y-3">
                  <ScoreBar label="Trend quality" value={result.scoreBreakdown.trend} max={25} />
                  <ScoreBar label="Relative strength" value={result.scoreBreakdown.relativeStrength} max={25} />
                  <ScoreBar label="Pullback quality" value={result.scoreBreakdown.pullback} max={20} />
                  <ScoreBar label="Volatility quality" value={result.scoreBreakdown.volatility} max={15} />
                  <ScoreBar label="Trigger quality" value={result.scoreBreakdown.trigger} max={15} />
                  <div className="flex justify-between border-t border-border pt-3 font-mono text-sm">
                    <span>Total</span>
                    <span>{fmtScore(result.scoreBreakdown.total)} / 100</span>
                  </div>
                  <p className="text-xs text-subtle">RGLM Score is a rule score, not a probability of profit.</p>
                </div>
              ) : (
                <p className="mt-3 text-sm text-muted">No score — no qualified candidate.</p>
              )}
            </section>
          </div>
        ) : null}

        {result ? (
          <>
            <div className="mt-6 flex gap-2 overflow-x-auto pb-1">
              {(
                [
                  ["checklist", "RGLM checklist"],
                  ["score", "Qualified names"],
                  ["stats", "Scan statistics"],
                  ["chart", "Price chart"],
                  ["explain", "Explain"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setPanel(id)}
                  className={cn(
                    "h-10 shrink-0 rounded-md border px-3 text-xs uppercase tracking-wider",
                    panel === id ? "border-accent bg-elevated text-fg" : "border-border text-muted",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="mt-3 rounded-xl border border-border bg-surface p-5">
              {panel === "checklist" ? (
                <ul className="divide-y divide-border">
                  {result.checklist.length ? result.checklist.map((g) => <GateRow key={g.name} gate={g} />) : (
                    <li className="text-sm text-muted">No candidate checklist — market or coverage gate closed the scan.</li>
                  )}
                </ul>
              ) : null}

              {panel === "score" ? (
                <div className="space-y-3">
                  {result.rankedQualified.length === 0 ? (
                    <p className="text-sm text-muted">No score-qualified candidates.</p>
                  ) : (
                    result.rankedQualified.map((c, i) => (
                      <div key={c.ticker} className="flex items-center justify-between gap-3 border-b border-border py-2 last:border-0">
                        <div>
                          <div className="font-mono text-sm">
                            {i + 1}. {c.ticker}
                          </div>
                          <div className="text-xs text-muted">{c.company}</div>
                        </div>
                        <div className="text-right font-mono text-sm tabular-nums">
                          {fmtScore(c.score)} · {c.direction}
                        </div>
                      </div>
                    ))
                  )}
                  {result.rejectedHighScores.length ? (
                    <div className="pt-2">
                      <h4 className="text-xs uppercase tracking-wider text-subtle">Rejected / not ranked</h4>
                      <ul className="mt-2 space-y-2">
                        {result.rejectedHighScores.map((r) => (
                          <li key={r.ticker} className="text-sm">
                            <span className="font-mono">{r.ticker}</span>
                            <span className="text-muted"> — {r.failedGates.join(", ") || r.detail}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                </div>
              ) : null}

              {panel === "stats" ? (
                <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
                  <Stat k="Universe discovered" v={result.scanStatistics.universeDiscovered} />
                  <Stat k="Universe eligible" v={result.scanStatistics.universeEligible} />
                  <Stat k="Universe rejected" v={result.scanStatistics.universeRejected} />
                  <Stat k="Data-quality rejects" v={result.scanStatistics.dataQualityRejects} />
                  <Stat k="Insufficient-history" v={result.scanStatistics.insufficientHistoryRejects} />
                  <Stat k="Hard-gate survivors" v={result.scanStatistics.hardGateSurvivors} />
                  <Stat k="Score-qualified" v={result.scanStatistics.scoreQualified} />
                  <Stat k="S&P 500" v={`${result.scanStatistics.spxFound}/${result.scanStatistics.spxExpected}`} />
                  <Stat k="Nasdaq-100" v={`${result.scanStatistics.ndxFound}/${result.scanStatistics.ndxExpected}`} />
                  <Stat k="Provider requests" v={result.scanStatistics.providerRequests} />
                  <Stat k="Elapsed ms" v={result.scanStatistics.elapsedMs} />
                  <Stat k="Universe mode" v={result.universeMode} />
                </dl>
              ) : null}

              {panel === "chart" ? (
                chartData.length < 5 ? (
                  <p className="text-sm text-muted">Chart available only when a research signal is produced.</p>
                ) : (
                  <div className="h-72 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                        <CartesianGrid stroke="var(--color-line)" strokeDasharray="3 3" />
                        <XAxis dataKey="date" tick={{ fill: "var(--color-subtle)", fontSize: 10 }} minTickGap={24} />
                        <YAxis
                          domain={["auto", "auto"]}
                          tick={{ fill: "var(--color-subtle)", fontSize: 10 }}
                          width={56}
                        />
                        <Tooltip
                          contentStyle={{
                            background: "var(--color-elevated)",
                            border: "1px solid var(--color-border)",
                            fontSize: 12,
                          }}
                        />
                        <Line type="monotone" dataKey="close" stroke="var(--color-fg)" dot={false} strokeWidth={1.6} name="Close" />
                        <Line type="monotone" dataKey="sma20" stroke="var(--color-muted)" dot={false} strokeWidth={1} name="SMA20" />
                        <Line type="monotone" dataKey="sma50" stroke="var(--color-warn)" dot={false} strokeWidth={1} name="SMA50" />
                        <Line type="monotone" dataKey="sma200" stroke="var(--color-subtle)" dot={false} strokeWidth={1} name="SMA200" />
                        {result.winner ? (
                          <>
                            <ReferenceLine y={result.winner.referenceEntry} stroke="var(--color-accent)" strokeDasharray="4 4" />
                            <ReferenceLine y={result.winner.stop} stroke="var(--color-short)" strokeDasharray="4 4" />
                            <ReferenceLine y={result.winner.target3R} stroke="var(--color-long)" strokeDasharray="4 4" />
                          </>
                        ) : null}
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )
              ) : null}

              {panel === "explain" ? (
                <div>
                  <Button size="sm" variant="secondary" onClick={onExplain} disabled={phase !== "IDLE"}>
                    {phase === "EXPLAINING" ? <Loader2 className="animate-spin" /> : <Info />}
                    Explain this result
                  </Button>
                  <p className="mt-2 text-xs text-subtle">
                    AI may only describe the stored JSON. It cannot change the mathematical decision.
                  </p>
                  {explain ? <div className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-muted">{explain}</div> : null}
                </div>
              ) : null}
            </div>
          </>
        ) : null}

        <Panel title="Diagnostics" defaultOpen={false}>
          <ul className="space-y-2 font-mono text-xs text-muted">
            <li className="flex items-center gap-2">
              <Database className="size-3.5" /> Cached symbols: {status?.cachedSymbols ?? 0}
            </li>
            <li className="flex items-center gap-2">
              <Shield className="size-3.5" /> Token configured: {status?.tokenConfigured ? "yes" : "no"} (value never displayed)
            </li>
            <li className="flex items-center gap-2">
              <BarChart3 className="size-3.5" /> Price basis: split-adjusted OHLC
            </li>
            <li>Universe kind: CURRENT-CONSTITUENT UNIVERSE — not a point-in-time historical universe.</li>
            <li>Daily API calls: {status?.limits.apiCallsUsedToday ?? 0} / {status?.limits.dailyLimit ?? "—"} ({status?.limits.apiCallsUsageDate ?? "—"})</li>
            <li>Minute requests remaining: {status?.limits.remainingMinuteRequests ?? "—"}</li>
          </ul>
          {status?.events?.length ? (
            <ul className="mt-3 space-y-1 text-xs text-subtle">
              {status.events.map((e, i) => (
                <li key={`${e.created_at}-${i}`}>
                  {e.event_type}: {e.message}
                </li>
              ))}
            </ul>
          ) : null}
        </Panel>

        <p className="mt-8 max-w-3xl text-xs leading-relaxed text-subtle">
          RGLM is a systematic research tool. It does not execute trades, accept deposits, or connect to a broker.
          If the provider cannot verify coverage, the engine stops and returns NO TRADE. Never treat a research
          stop, target, or theoretical size as an order.
        </p>
      </main>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string | number }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-subtle">{k}</dt>
      <dd className="font-mono tabular-nums text-fg">{v}</dd>
    </div>
  );
}
