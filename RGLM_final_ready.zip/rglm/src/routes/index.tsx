import { createFileRoute } from "@tanstack/react-router";
import { RglmTerminal } from "@/components/rglm-terminal";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RglmTerminal />;
}
