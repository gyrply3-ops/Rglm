import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { PRICE_BASIS, STRATEGY_VERSION } from "./rglm/constants.ts";
import { lastCompletedWeekday } from "./rglm/bars.ts";
import type { RglmResult } from "./rglm/types.ts";

const modeSchema = z.object({
  mode: z.enum(["LIVE", "DEMO"]),
  eodhdApiKey: z.string().trim().max(512).optional(),
});

const credentialsSchema = z.object({
  eodhdApiKey: z.string().trim().max(512).optional(),
});

export type StatusPayload = {
  provider: "EODHD";
  apiStatus: "CONNECTED" | "NOT_CONFIGURED" | "ERROR" | "RATE_LIMITED";
  tokenConfigured: boolean;
  message: string;
  latestProbeSession: string | null;
  expectedSession: string;
  limits: {
    dailyLimit: number | null;
    apiCallsUsedToday: number | null;
    apiCallsUsageDate: string | null;
    remainingMinuteRequests: number | null;
  };
  cachedSymbols: number;
  strategyVersion: string;
  priceBasis: string;
  lastScan: RglmResult | null;
  events: Array<{ event_type: string; message: string; created_at: string }>;
};

export const getRglmStatus = createServerFn({ method: "POST" })
  .validator((input: unknown) => credentialsSchema.parse(input ?? {}))
  .handler(async ({ data }): Promise<StatusPayload> => {
  const { createProvider } = await import("./provider/eodhd.ts");
  const { cachedSymbolCount, latestScan, recentProviderEvents } = await import("./scan/repository.ts");
  const provider = createProvider(data.eodhdApiKey);
  const health = await provider.getDataStatus();
  const [cached, lastScan, events] = await Promise.all([
    cachedSymbolCount(),
    latestScan(),
    recentProviderEvents(),
  ]);
  return {
    provider: "EODHD",
    apiStatus: health.apiStatus,
    tokenConfigured: health.tokenConfigured,
    message: health.message,
    latestProbeSession: health.latestProbeSession,
    expectedSession: lastCompletedWeekday(),
    limits: {
      dailyLimit: health.limits.dailyLimit,
      apiCallsUsedToday: health.limits.requestsUsedHint,
      apiCallsUsageDate: health.limits.requestsUsedDate,
      remainingMinuteRequests: health.limits.remainingRequestHint,
    },
    cachedSymbols: cached,
    strategyVersion: STRATEGY_VERSION,
    priceBasis: PRICE_BASIS,
    lastScan,
    events,
  };
  });

export const runRglmScan = createServerFn({ method: "POST" })
  .validator((input: unknown) => modeSchema.parse(input))
  .handler(async ({ data }): Promise<RglmResult> => {
    const { runDemoScan, runLiveScan } = await import("./scan/pipeline.ts");
    if (data.mode === "DEMO") return runDemoScan();
    return runLiveScan(data.eodhdApiKey);
  });

export const explainRglmScan = createServerFn({ method: "POST" })
  .validator((input: unknown) => z.object({ scanId: z.string().min(1).max(80) }).parse(input))
  .handler(async ({ data }): Promise<{ ok: true; text: string } | { ok: false; error: string }> => {
    const { getScan } = await import("./scan/repository.ts");
    const result = await getScan(data.scanId);
    if (!result) return { ok: false, error: "Scan not found." };
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "AI explanation is not available in this environment." };

    const payload = {
      strategyVersion: result.strategyVersion,
      status: result.status,
      reasonCode: result.reasonCode,
      reasonText: result.reasonText,
      marketRegime: result.marketRegime,
      volatilityState: result.volatilityState,
      spyVolRatio: result.spyVolRatio,
      spyVolThreshold: result.spyVolThreshold,
      coverageStatus: result.coverageStatus,
      dataStatus: result.dataStatus,
      universeMode: result.universeMode,
      latestCompletedSession: result.latestCompletedSession,
      winner: result.winner,
      scoreBreakdown: result.scoreBreakdown,
      checklist: result.checklist,
      rankedQualified: result.rankedQualified,
      rejectedHighScores: result.rejectedHighScores,
      scanStatistics: result.scanStatistics,
      spy: result.spy,
    };

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        messages: [
          {
            role: "system",
            content:
              "You explain an already-calculated RGLM v0.1 research result. You may not select stocks, change scores, alter rankings, fill missing data, predict profits, or express certainty. Use only the JSON numbers. If dataStatus is DEMO, say DEMO DATA clearly. RGLM Score is not a probability. Research levels are not fills.",
          },
          {
            role: "user",
            content: `Explain this structured RGLM result in plain language for a research terminal:\n${JSON.stringify(payload)}`,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false, error: `Explanation service error ${res.status}.` };
    const body = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const text = body.choices?.[0]?.message?.content?.trim();
    if (!text) return { ok: false, error: "Empty explanation." };
    return { ok: true, text };
  });
