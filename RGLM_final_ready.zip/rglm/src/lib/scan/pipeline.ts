import { lastCompletedWeekday, mergeBarRange } from "../rglm/bars.ts";
import { ENGINE_HISTORY_BARS, MIN_PRODUCTION_ELIGIBLE, PRICE_BASIS, STRATEGY_VERSION } from "../rglm/constants.ts";
import { calculateRGLMSignal } from "../rglm/engine.ts";
import type { EngineSymbol, RglmResult } from "../rglm/types.ts";
import { buildDemoMarket } from "../provider/demo-market.ts";
import { createProvider, type ProviderHealth } from "../provider/eodhd.ts";
import { estimateWorkload } from "../provider/budget.ts";
import { cachedSymbolCount, loadBars, logProviderEvent, nextSnapshotId, saveBars, saveScan } from "./repository.ts";

export type AppStatus = {
  health: ProviderHealth;
  cachedSymbols: number;
  lastScan: RglmResult | null;
  expectedSession: string;
  priceBasis: string;
  strategyVersion: string;
};

export async function runDemoScan(): Promise<RglmResult> {
  const started = new Date();
  const asOf = lastCompletedWeekday();
  const market = buildDemoMarket(asOf);
  const snapshotId = await nextSnapshotId(started);
  const result = calculateRGLMSignal({
    spyBars: market.spy,
    symbols: market.symbols,
    asOfDate: market.asOfDate,
    timestamp: started.toISOString(),
    dataSnapshotId: snapshotId,
    dataStatus: "DEMO",
    universeMode: "DEMO_RESEARCH",
    coverageStatus: "COMPLETE",
    coverageReason: "DEMO RESEARCH MODE — synthetic bars. Not live EODHD coverage.",
    universeDiscovered: market.discovered,
    universeRejected: market.rejected,
    spxFound: [...market.spxTickers].filter((t) => market.symbols.some((s) => s.ticker === t)).length,
    spxExpected: market.spxTickers.size,
    ndxFound: [...market.ndxTickers].filter((t) => market.symbols.some((s) => s.ticker === t)).length,
    ndxExpected: market.ndxTickers.size,
    cacheHits: market.symbols.length,
    providerRequests: 0,
    elapsedMs: Date.now() - started.getTime(),
  });
  result.scanStatistics.elapsedMs = Date.now() - started.getTime();
  await saveScan(result, started, new Date());
  await logProviderEvent("DEMO_SCAN", `${result.status} ${result.reasonCode}`, {
    snapshotId,
    eligible: result.eligibleCount,
  });
  return result;
}

function liveNoTrade(
  snapshotId: string,
  timestamp: string,
  code: RglmResult["reasonCode"],
  text: string,
  health: ProviderHealth,
  extra: Partial<RglmResult> = {},
): RglmResult {
  const emptySpy = {
    lastDate: health.latestProbeSession ?? "",
    close: NaN,
    sma20: null,
    sma50: null,
    sma200: null,
    atr20: null,
    return63: null,
    volRatio: null,
    volThreshold: null,
    regime: "UNAVAILABLE" as const,
    volatilityState: "UNAVAILABLE" as const,
    barCount: 0,
    valid: false,
    failReason: code,
  };
  return {
    strategyVersion: STRATEGY_VERSION,
    status: "NO_TRADE",
    reasonCode: code,
    reasonText: text,
    timestamp,
    dataSnapshotId: snapshotId,
    marketRegime: "UNAVAILABLE",
    volatilityStress: false,
    volatilityState: "UNAVAILABLE",
    spyVolRatio: null,
    spyVolThreshold: null,
    universeCount: 0,
    eligibleCount: 0,
    hardGateSurvivors: 0,
    qualifiedCount: 0,
    coverageStatus: code === "INSUFFICIENT_MARKET_COVERAGE" ? "INSUFFICIENT" : "UNKNOWN",
    dataStatus: code === "API_NOT_CONFIGURED" ? "NOT_CONFIGURED" : "ERROR",
    universeMode: "PRODUCTION",
    universeKind: "CURRENT_CONSTITUENT_UNIVERSE",
    provider: "EODHD",
    latestCompletedSession: health.latestProbeSession,
    winner: null,
    scoreBreakdown: null,
    reasons: [text],
    scanStatistics: {
      universeDiscovered: 0,
      universeEligible: 0,
      universeRejected: 0,
      dataQualityRejects: 0,
      insufficientHistoryRejects: 0,
      hardGateSurvivors: 0,
      scoreQualified: 0,
      finalCandidate: null,
      spxFound: 0,
      spxExpected: 0,
      ndxFound: 0,
      ndxExpected: 0,
      expandedUniverse: 0,
      uniqueEligible: 0,
      cacheHits: 0,
      providerRequests: 0,
      elapsedMs: 0,
    },
    spy: emptySpy,
    checklist: [],
    rankedQualified: [],
    rejectedHighScores: [],
    chart: [],
    researchDisclaimer:
      "Research / paper only. Live coverage was not complete. No fabricated universe was used.",
    ...extra,
  };
}

export async function runLiveScan(tokenOverride?: string): Promise<RglmResult> {
  const started = new Date();
  const snapshotId = await nextSnapshotId(started);
  const provider = createProvider(tokenOverride);
  const health = await provider.getDataStatus();
  await logProviderEvent("LIVE_STATUS", health.apiStatus, { message: health.message });

  if (health.apiStatus === "NOT_CONFIGURED") {
    const result = liveNoTrade(
      snapshotId,
      started.toISOString(),
      "API_NOT_CONFIGURED",
      "EODHD API token is not configured. No live scan.",
      health,
    );
    await saveScan(result, started, new Date());
    return result;
  }
  if (health.apiStatus === "RATE_LIMITED") {
    const result = liveNoTrade(snapshotId, started.toISOString(), "RATE_LIMITED", health.message, health);
    await saveScan(result, started, new Date());
    return result;
  }
  if (health.apiStatus !== "CONNECTED") {
    const result = liveNoTrade(snapshotId, started.toISOString(), "DATA_ERROR", health.message, health);
    await saveScan(result, started, new Date());
    return result;
  }

  const spyRes = await provider.getSpyHistory();
  if (!spyRes.ok) {
    const code = spyRes.kind === "RATE_LIMITED" ? "RATE_LIMITED" : "BENCHMARK_DATA_UNAVAILABLE";
    const result = liveNoTrade(snapshotId, started.toISOString(), code, spyRes.message, health);
    await saveScan(result, started, new Date());
    return result;
  }
  await saveBars("SPY", "US", spyRes.bars, "EODHD");

  const indexes = await provider.getSpxAndNdx();
  if (!indexes.ok) {
    const result = liveNoTrade(
      snapshotId,
      started.toISOString(),
      "INDEX_DATA_UNAVAILABLE",
      indexes.message,
      health,
    );
    await saveScan(result, started, new Date());
    return result;
  }

  const universe = await provider.getExchangeSymbols("US");
  if (!universe.ok) {
    const result = liveNoTrade(
      snapshotId,
      started.toISOString(),
      universe.kind === "RATE_LIMITED" ? "RATE_LIMITED" : "DATA_ERROR",
      universe.message,
      health,
    );
    await saveScan(result, started, new Date());
    return result;
  }

  // The US exchange-symbol-list can contain the same ticker on multiple venues.
  // RGLM production coverage is defined in unique ticker names, so deduplicate
  // before counting or scanning the universe.
  const eligibleByTicker = new Map<string, (typeof universe.rows)[number]>();
  for (const row of universe.rows) {
    if (row.status !== "ELIGIBLE") continue;
    if (!eligibleByTicker.has(row.ticker)) eligibleByTicker.set(row.ticker, row);
  }
  const eligible = [...eligibleByTicker.values()];
  const rejected = universe.rows.length - eligible.length;
  const spxSet = new Set(indexes.spx.map((m) => m.ticker));
  const ndxSet = new Set(indexes.ndx.map((m) => m.ticker));

  const missing: typeof eligible = [];
  const cached: EngineSymbol[] = [];
  for (const row of eligible) {
    const bars = await loadBars(row.ticker, row.exchange || "US");
    if (bars && bars.length >= ENGINE_HISTORY_BARS) {
      cached.push({
        ticker: row.ticker,
        company: row.company,
        exchange: row.exchange || "US",
        bars,
        inSpx: spxSet.has(row.ticker),
        inNdx: ndxSet.has(row.ticker),
      });
    } else {
      missing.push(row);
    }
  }

  const dailyRemaining = Math.max(0, provider.budget.dailyLimit - provider.budget.dailyCount);
  const workload = estimateWorkload({
    missingHistories: missing.length,
    needUniverse: false,
    needIndexes: false,
    needSpy: false,
    bulkDays: 0,
  });

  // Warm the local history cache in small concurrent batches. The cap is deliberate:
  // the scan endpoint must remain responsive, and additional runs can continue the
  // cache warm-up. A live signal is never returned until 3,000 validated symbols exist.
  if (cached.length < MIN_PRODUCTION_ELIGIBLE && missing.length > 0 && dailyRemaining > 0) {
    const maxNew = Math.min(240, missing.length, Math.max(0, dailyRemaining - 1));
    const deadline = Date.now() + 15_000;
    const queue = missing.slice(0, maxNew);
    const workers = Math.min(8, queue.length);
    let cursor = 0;

    const worker = async () => {
      while (Date.now() < deadline) {
        const index = cursor++;
        if (index >= queue.length) return;
        const row = queue[index]!;
        const exchange = row.exchange || "US";
        const hist = await provider.getHistoricalDailyBars(`${row.ticker}.${exchange}`);
        if (!hist.ok) {
          if (hist.kind === "RATE_LIMITED") return;
          continue;
        }
        const existing = (await loadBars(row.ticker, exchange)) ?? [];
        const merged = mergeBarRange(existing, hist.bars);
        await saveBars(row.ticker, exchange, merged, "EODHD");
        if (merged.length >= ENGINE_HISTORY_BARS) {
          cached.push({
            ticker: row.ticker,
            company: row.company,
            exchange,
            bars: merged,
            inSpx: spxSet.has(row.ticker),
            inNdx: ndxSet.has(row.ticker),
          });
        }
      }
    };

    await Promise.all(Array.from({ length: workers }, () => worker()));
  }

  if (cached.length < MIN_PRODUCTION_ELIGIBLE) {
    const result = calculateRGLMSignal({
      spyBars: spyRes.bars,
      symbols: cached,
      asOfDate: spyRes.bars[spyRes.bars.length - 1]?.date ?? lastCompletedWeekday(),
      timestamp: started.toISOString(),
      dataSnapshotId: snapshotId,
      dataStatus: "LIVE",
      universeMode: "PRODUCTION",
      coverageStatus: "INSUFFICIENT",
      coverageReason: `Validated cache ${cached.length} / ${MIN_PRODUCTION_ELIGIBLE} required. ${workload.note} Remaining daily API-call budget ~${dailyRemaining}.`,
      universeDiscovered: universe.rows.length,
      universeRejected: rejected,
      spxFound: indexes.spx.length,
      spxExpected: indexes.spx.length,
      ndxFound: indexes.ndx.length,
      ndxExpected: indexes.ndx.length,
      cacheHits: cached.length,
      providerRequests: provider.budget.requestsUsed,
      elapsedMs: Date.now() - started.getTime(),
    });
    result.scanStatistics.elapsedMs = Date.now() - started.getTime();
    await saveScan(result, started, new Date());
    await logProviderEvent("LIVE_SCAN", result.reasonCode, {
      cached: cached.length,
      discovered: universe.rows.length,
    });
    return result;
  }

  const result = calculateRGLMSignal({
    spyBars: spyRes.bars,
    symbols: cached,
    asOfDate: spyRes.bars[spyRes.bars.length - 1]?.date ?? lastCompletedWeekday(),
    timestamp: started.toISOString(),
    dataSnapshotId: snapshotId,
    dataStatus: "LIVE",
    universeMode: "PRODUCTION",
    coverageStatus: "COMPLETE",
    universeDiscovered: universe.rows.length,
    universeRejected: rejected,
    spxFound: indexes.spx.filter((m) => cached.some((s) => s.ticker === m.ticker)).length,
    spxExpected: indexes.spx.length,
    ndxFound: indexes.ndx.filter((m) => cached.some((s) => s.ticker === m.ticker)).length,
    ndxExpected: indexes.ndx.length,
    cacheHits: cached.length,
    providerRequests: provider.budget.requestsUsed,
    elapsedMs: Date.now() - started.getTime(),
  });
  result.scanStatistics.elapsedMs = Date.now() - started.getTime();
  await saveScan(result, started, new Date());
  await logProviderEvent("LIVE_SCAN", result.reasonCode, { eligible: cached.length });
  return result;
}

export { PRICE_BASIS };
