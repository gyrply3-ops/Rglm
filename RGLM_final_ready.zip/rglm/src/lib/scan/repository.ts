import { getSql } from "../db.ts";
import type { DailyBar, RglmResult } from "../rglm/types.ts";

export async function nextSnapshotId(now = new Date()): Promise<string> {
  const sql = await getSql();
  const day = now.toISOString().slice(0, 10).replaceAll("-", "_");
  const prefix = `RGLM_SCAN_${day}_`;
  const rows = await sql<{ id: string }>`
    select id from scan_runs where id like ${prefix + "%"} order by id desc limit 1
  `;
  const last = rows[0]?.id;
  const n = last ? Number(last.slice(prefix.length)) + 1 : 1;
  return `${prefix}${String(Number.isFinite(n) ? n : 1).padStart(3, "0")}`;
}

export async function saveScan(result: RglmResult, startedAt: Date, endedAt: Date): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into scan_runs (
      id, strategy_version, status, reason_code, reason_text, data_snapshot_id,
      coverage_status, data_status, provider, market_regime, volatility_stress,
      latest_session, universe_discovered, universe_eligible, result_json,
      started_at, ended_at
    ) values (
      ${result.dataSnapshotId},
      ${result.strategyVersion},
      ${result.status},
      ${result.reasonCode},
      ${result.reasonText},
      ${result.dataSnapshotId},
      ${result.coverageStatus},
      ${result.dataStatus},
      ${result.provider},
      ${result.marketRegime},
      ${result.volatilityStress},
      ${result.latestCompletedSession},
      ${result.universeCount},
      ${result.eligibleCount},
      ${JSON.stringify(result)},
      ${startedAt.toISOString()},
      ${endedAt.toISOString()}
    )
  `;
  if (result.winner) {
    await sql`
      insert into scan_candidates (
        scan_id, ticker, company, direction, score, passed_hard_gates,
        reject_gates, score_breakdown, rank, is_winner
      ) values (
        ${result.dataSnapshotId},
        ${result.winner.ticker},
        ${result.winner.company},
        ${result.winner.direction},
        ${result.winner.score},
        ${true},
        ${"[]"},
        ${JSON.stringify(result.scoreBreakdown)},
        ${1},
        ${true}
      )
    `;
  }
  await sql`
    delete from scan_runs where id not in (
      select id from (
        select id from scan_runs order by created_at desc limit 20
      ) keep
    )
  `;
}

export async function latestScan(): Promise<RglmResult | null> {
  const sql = await getSql();
  const rows = await sql<{ result_json: string }>`
    select result_json from scan_runs order by created_at desc limit 1
  `;
  if (!rows[0]) return null;
  try {
    return JSON.parse(rows[0].result_json) as RglmResult;
  } catch {
    return null;
  }
}

export async function getScan(id: string): Promise<RglmResult | null> {
  const sql = await getSql();
  const rows = await sql<{ result_json: string }>`
    select result_json from scan_runs where id = ${id} limit 1
  `;
  if (!rows[0]) return null;
  try {
    return JSON.parse(rows[0].result_json) as RglmResult;
  } catch {
    return null;
  }
}

export async function loadBars(ticker: string, exchange: string): Promise<DailyBar[] | null> {
  const sql = await getSql();
  const rows = await sql<{ bars_json: string }>`
    select bars_json from daily_bars where ticker = ${ticker} and exchange = ${exchange} limit 1
  `;
  if (!rows[0]) return null;
  try {
    const parsed = JSON.parse(rows[0].bars_json) as DailyBar[];
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

export async function saveBars(
  ticker: string,
  exchange: string,
  bars: DailyBar[],
  source: string,
): Promise<void> {
  const sql = await getSql();
  const first = bars[0]?.date ?? null;
  const last = bars[bars.length - 1]?.date ?? null;
  await sql`
    insert into daily_bars (
      ticker, exchange, bars_json, first_date, last_date, bar_count,
      data_source, data_version, price_basis, retrieved_at, validation_status
    ) values (
      ${ticker}, ${exchange}, ${JSON.stringify(bars)}, ${first}, ${last}, ${bars.length},
      ${source}, ${"v1"}, ${"SPLIT_ADJUSTED_OHLC"}, ${new Date().toISOString()}, ${"STORED"}
    )
    on conflict (ticker, exchange) do update set
      bars_json = excluded.bars_json,
      first_date = excluded.first_date,
      last_date = excluded.last_date,
      bar_count = excluded.bar_count,
      data_source = excluded.data_source,
      retrieved_at = excluded.retrieved_at
  `;
}

export async function cachedSymbolCount(): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`select count(*)::int as n from daily_bars`;
  return rows[0]?.n ?? 0;
}

export async function logProviderEvent(eventType: string, message: string, meta?: unknown): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into provider_events (event_type, message, meta)
    values (${eventType}, ${message}, ${meta ? JSON.stringify(meta) : null})
  `;
}

export async function recentProviderEvents(): Promise<Array<{ event_type: string; message: string; created_at: string }>> {
  const sql = await getSql();
  return sql<{ event_type: string; message: string; created_at: string }>`
    select event_type, message, created_at::text from provider_events order by id desc limit 12
  `;
}
