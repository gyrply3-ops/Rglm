import type { ClassificationStatus } from "../rglm/types.ts";

const ALLOWED_TYPES = new Set([
  "common stock",
  "common shares",
  "ordinary share",
  "ordinary shares",
  "common",
]);

const EXCLUDED_TYPE_FRAGMENTS = [
  "etf",
  "etn",
  "etp",
  "fund",
  "preferred",
  "warrant",
  "right",
  "unit",
  "note",
  "bond",
  "future",
  "option",
  "index",
  "forex",
  "crypto",
  "currency",
  "structured",
  "certificate",
  "money market",
  "closed-end",
  "closed end",
  "mutual",
  "trust",
];

const NAME_BLOCK =
  /\b(ETF|ETN|ETP|FUND|WARRANT|RIGHTS?|PREFERRED|PFD|UNIT TRUST|CLOSED[ -]?END|NOTE|BOND|FUTURES?|OPTION|INDEX|TRUST)\b/i;

const SYMBOL_BLOCK = /(-P|-WS|-W|-U|-R|\.WS|\.W|\.U|\.R|\.P|\.PR)$/i;

const US_COUNTRIES = new Set(["usa", "united states", "united states of america", "us"]);
const US_EXCHANGES = new Set([
  "us",
  "nyse",
  "nasdaq",
  "nasdaqgs",
  "nasdaqgm",
  "nasdaqcm",
  "nyse mkt",
  "nyse american",
  "amex",
  "bats",
  "nyse arca",
  "nysemkt",
]);

export type InstrumentRow = {
  code?: unknown;
  ticker?: unknown;
  name?: unknown;
  type?: unknown;
  exchange?: unknown;
  country?: unknown;
  currency?: unknown;
  isin?: unknown;
};

export type Classification = {
  ticker: string;
  company: string;
  exchange: string;
  country: string;
  currency: string;
  instrumentType: string;
  isin: string | null;
  status: ClassificationStatus;
  reason: string | null;
};

function str(v: unknown): string {
  return typeof v === "string" ? v.trim() : v == null ? "" : String(v).trim();
}

export function classifyInstrument(row: InstrumentRow): Classification {
  const ticker = str(row.code || row.ticker).toUpperCase();
  const company = str(row.name);
  const exchange = str(row.exchange).toUpperCase();
  const country = str(row.country);
  const currency = str(row.currency).toUpperCase();
  const instrumentType = str(row.type);
  const isin = str(row.isin) || null;

  const reject = (reason: string): Classification => ({
    ticker,
    company,
    exchange,
    country,
    currency,
    instrumentType,
    isin,
    status: "REJECTED",
    reason,
  });

  if (!ticker) return reject("Missing ticker.");
  if (!instrumentType) return reject("Instrument classification missing — rejected as uncertain.");

  const typeLc = instrumentType.toLowerCase();
  if (EXCLUDED_TYPE_FRAGMENTS.some((f) => typeLc.includes(f))) {
    return reject(`Excluded instrument type: ${instrumentType}.`);
  }
  if (![...ALLOWED_TYPES].some((t) => typeLc === t || typeLc.startsWith(t))) {
    return reject(`Type '${instrumentType}' is not ordinary U.S. common equity.`);
  }
  if (NAME_BLOCK.test(company)) {
    return reject(`Name indicates a non-common instrument: ${company}.`);
  }
  if (SYMBOL_BLOCK.test(ticker)) {
    return reject(`Ticker suffix indicates warrant/right/preferred/unit.`);
  }
  if (currency && currency !== "USD") {
    return reject(`Currency ${currency} is not USD.`);
  }
  if (country && !US_COUNTRIES.has(country.toLowerCase())) {
    return reject(`Country '${country}' is not U.S.`);
  }
  if (exchange && !US_EXCHANGES.has(exchange.toLowerCase())) {
    return reject(`Exchange '${exchange}' is not a recognised U.S. listing venue.`);
  }

  return {
    ticker,
    company: company || ticker,
    exchange: exchange || "US",
    country: country || "USA",
    currency: currency || "USD",
    instrumentType,
    isin,
    status: "ELIGIBLE",
    reason: null,
  };
}

export function parseIndexComponents(payload: unknown): Array<{ ticker: string; company: string; exchange: string }> {
  if (!payload || typeof payload !== "object") return [];
  const root = payload as Record<string, unknown>;
  const components = root.Components ?? root.components;
  const out: Array<{ ticker: string; company: string; exchange: string }> = [];
  const push = (code: string, name: string, exch: string) => {
    if (code) out.push({ ticker: code.toUpperCase(), company: name || code, exchange: (exch || "US").toUpperCase() });
  };
  if (Array.isArray(components)) {
    for (const c of components) {
      if (!c || typeof c !== "object") continue;
      const row = c as Record<string, unknown>;
      push(str(row.Code ?? row.code ?? row.Ticker), str(row.Name ?? row.name), str(row.Exchange ?? row.exchange));
    }
    return out;
  }
  if (components && typeof components === "object") {
    for (const v of Object.values(components as Record<string, unknown>)) {
      if (!v || typeof v !== "object") continue;
      const row = v as Record<string, unknown>;
      push(str(row.Code ?? row.code ?? row.Ticker), str(row.Name ?? row.name), str(row.Exchange ?? row.exchange));
    }
  }
  return out;
}
