import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { classifyInstrument, parseIndexComponents } from "./classify.ts";

describe("classifyInstrument", () => {
  it("accepts U.S. common stock", () => {
    const r = classifyInstrument({
      code: "CAT",
      name: "Caterpillar Inc",
      type: "Common Stock",
      exchange: "NYSE",
      country: "USA",
      currency: "USD",
    });
    assert.equal(r.status, "ELIGIBLE");
  });
  it("rejects ETFs", () => {
    const r = classifyInstrument({
      code: "SPY",
      name: "SPDR S&P 500 ETF Trust",
      type: "ETF",
      exchange: "NYSE ARCA",
      country: "USA",
      currency: "USD",
    });
    assert.equal(r.status, "REJECTED");
  });
  it("rejects missing type as uncertain", () => {
    const r = classifyInstrument({ code: "ZZZ", name: "Mystery", type: "", exchange: "NYSE" });
    assert.equal(r.status, "REJECTED");
    assert.match(r.reason ?? "", /uncertain/i);
  });
  it("rejects preferred / warrants / funds", () => {
    assert.equal(
      classifyInstrument({ code: "BAC-P", name: "Bank Pref", type: "Preferred Stock", exchange: "NYSE" }).status,
      "REJECTED",
    );
    assert.equal(
      classifyInstrument({ code: "XYZ.WS", name: "Warrant Co", type: "Common Stock", exchange: "NYSE" }).status,
      "REJECTED",
    );
  });
});

describe("parseIndexComponents", () => {
  it("reads object-map Components from fundamentals payload", () => {
    const rows = parseIndexComponents({
      Components: {
        "0": { Code: "AAPL", Exchange: "US", Name: "Apple" },
        "1": { Code: "MSFT", Exchange: "US", Name: "Microsoft" },
      },
    });
    assert.equal(rows.length, 2);
    assert.equal(rows[0]!.ticker, "AAPL");
  });
  it("returns empty on unknown shape rather than guessing", () => {
    assert.deepEqual(parseIndexComponents(null), []);
    assert.deepEqual(parseIndexComponents({ foo: 1 }), []);
  });
});
