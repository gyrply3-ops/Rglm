import assert from "node:assert/strict";
import { test } from "node:test";
import { EODHDMarketDataProvider } from "./eodhd.ts";

test("EODHD provider refuses live mode without a token", async () => {
  const previous = process.env.EODHD_API_TOKEN;
  delete process.env.EODHD_API_TOKEN;
  try {
    const provider = new EODHDMarketDataProvider();
    assert.equal(provider.tokenConfigured(), false);
    const health = await provider.getDataStatus();
    assert.equal(health.apiStatus, "NOT_CONFIGURED");
    assert.equal(health.tokenConfigured, false);
  } finally {
    if (previous === undefined) delete process.env.EODHD_API_TOKEN;
    else process.env.EODHD_API_TOKEN = previous;
  }
});
