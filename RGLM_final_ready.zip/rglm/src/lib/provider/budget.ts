/**
 * Request-budget manager for EODHD.
 *
 * EODHD has two different counters:
 *  - HTTP requests/minute
 *  - API calls/day (the daily spend/cost of a request)
 * Keep them separate so a 100-call bulk request does not incorrectly
 * consume 100 requests from the minute-rate bucket.
 */

export type BudgetState = {
  requestsUsed: number;
  requestsFailed: number;
  bulkRequests: number;
  retries: number;
  windowStartMs: number;
  windowCount: number;
  dailyDate: string;
  dailyCount: number;
  rateLimited: boolean;
  remainingRequestHint: number | null;
  perMinuteLimit: number;
  dailyLimit: number;
};

export type BudgetDecision = {
  allowed: boolean;
  reason: "OK" | "RATE_LIMIT" | "DAILY_LIMIT" | "MINUTE_LIMIT";
};

const MINUTE_MS = 60_000;

export function createBudget(now = new Date()): BudgetState {
  return {
    requestsUsed: 0,
    requestsFailed: 0,
    bulkRequests: 0,
    retries: 0,
    windowStartMs: now.getTime(),
    windowCount: 0,
    dailyDate: now.toISOString().slice(0, 10),
    dailyCount: 0,
    rateLimited: false,
    remainingRequestHint: null,
    perMinuteLimit: 1_000,
    dailyLimit: 100_000,
  };
}

export function estimateWorkload(opts: {
  missingHistories: number;
  needUniverse: boolean;
  needIndexes: boolean;
  needSpy: boolean;
  bulkDays: number;
}): { requests: number; bulk: number; apiCalls: number; note: string } {
  let requests = 0;
  let bulk = 0;
  let apiCalls = 0;
  if (opts.needUniverse) {
    requests += 1;
    apiCalls += 1;
  }
  if (opts.needIndexes) {
    requests += 2;
    apiCalls += 2;
  }
  if (opts.needSpy) {
    requests += 1;
    apiCalls += 1;
  }
  if (opts.bulkDays > 0) {
    bulk += opts.bulkDays;
    requests += opts.bulkDays;
    apiCalls += opts.bulkDays * 100;
  } else {
    requests += opts.missingHistories;
    apiCalls += opts.missingHistories;
  }
  return {
    requests,
    bulk,
    apiCalls,
    note: `${requests} estimated provider requests / ${apiCalls} estimated API calls (${bulk} bulk).`,
  };
}

/**
 * apiCost is the daily-call cost; requestCount is the HTTP-request cost.
 * For normal endpoints both are 1. A bulk endpoint may cost 100 API calls
 * while still consuming only one HTTP request from the per-minute limit.
 */
export function canSpend(
  state: BudgetState,
  apiCost = 1,
  requestCount = 1,
  now = Date.now(),
): BudgetDecision {
  const windowIsCurrent = now - state.windowStartMs < MINUTE_MS;
  if (state.rateLimited) return { allowed: false, reason: "RATE_LIMIT" };

  const today = new Date(now).toISOString().slice(0, 10);
  const dailyCount = today === state.dailyDate ? state.dailyCount : 0;
  if (dailyCount + apiCost > state.dailyLimit) return { allowed: false, reason: "DAILY_LIMIT" };

  const windowCount = windowIsCurrent ? state.windowCount : 0;
  if (windowCount + requestCount > state.perMinuteLimit) {
    return { allowed: false, reason: "MINUTE_LIMIT" };
  }

  if (state.remainingRequestHint != null && state.remainingRequestHint < requestCount) {
    return { allowed: false, reason: "RATE_LIMIT" };
  }

  return { allowed: true, reason: "OK" };
}

export function recordSuccess(
  state: BudgetState,
  now = Date.now(),
  remainingRequests?: number | null,
  bulk = false,
  apiCost = bulk ? 100 : 1,
  requestCount = 1,
  perMinuteLimit?: number | null,
): BudgetState {
  const today = new Date(now).toISOString().slice(0, 10);
  const resetDay = today !== state.dailyDate;
  const resetMin = now - state.windowStartMs >= MINUTE_MS;
  return {
    ...state,
    requestsUsed: state.requestsUsed + requestCount,
    bulkRequests: state.bulkRequests + (bulk ? 1 : 0),
    windowStartMs: resetMin ? now : state.windowStartMs,
    windowCount: (resetMin ? 0 : state.windowCount) + requestCount,
    dailyDate: today,
    dailyCount: (resetDay ? 0 : state.dailyCount) + apiCost,
    remainingRequestHint: remainingRequests ?? state.remainingRequestHint,
    perMinuteLimit: perMinuteLimit && perMinuteLimit > 0 ? perMinuteLimit : state.perMinuteLimit,
    rateLimited: false,
  };
}

export function recordFailure(state: BudgetState, rateLimited: boolean, now = Date.now()): BudgetState {
  return {
    ...state,
    requestsFailed: state.requestsFailed + 1,
    retries: state.retries + (rateLimited ? 1 : 0),
    rateLimited: rateLimited || state.rateLimited,
  };
}

export function clearRateLimit(state: BudgetState): BudgetState {
  return { ...state, rateLimited: false };
}

export function backoffMs(retry: number): number {
  const exp = Math.min(8, retry);
  return Math.min(30_000, 400 * 2 ** exp);
}
