/**
 * DEMO RESEARCH MARKET
 *
 * Synthetic daily bars for UI and engine verification. Every result that uses
 * this module MUST carry dataStatus: "DEMO" and a visible DEMO DATA label.
 * Never mix with EODHD live bars.
 */

import { ENGINE_HISTORY_BARS } from "../rglm/constants.ts";
import {
  applyLongPullbackTrigger,
  geometricWalk,
  lastCompletedWeekday,
  mulberry32,
  weekdaySessionsEnding,
} from "../rglm/bars.ts";
import type { DailyBar, EngineSymbol } from "../rglm/types.ts";
import { DEMO_EXPANDED, DEMO_NDX, DEMO_SPX, PLANTED_LONG } from "../universe/demo-names.ts";

export const DEMO_SOURCE = "DEMO_SYNTHETIC";

export type DemoMarket = {
  asOfDate: string;
  spy: DailyBar[];
  symbols: EngineSymbol[];
  spxTickers: Set<string>;
  ndxTickers: Set<string>;
  discovered: number;
  rejected: number;
};

function seedFromTicker(ticker: string): number {
  let h = 2166136261;
  for (let i = 0; i < ticker.length; i++) h = Math.imul(h ^ ticker.charCodeAt(i), 16777619);
  return h >>> 0;
}

export function buildDemoMarket(asOfDate = lastCompletedWeekday()): DemoMarket {
  const dates = weekdaySessionsEnding(asOfDate, ENGINE_HISTORY_BARS);
  const spyRng = mulberry32(0x53505931);
  const spy = geometricWalk(dates, 420, 0.00045, 0.0065, spyRng);

  const spxTickers = new Set(DEMO_SPX.map((x) => x.ticker));
  const ndxTickers = new Set(DEMO_NDX.map((x) => x.ticker));
  const planted = new Set<string>(PLANTED_LONG);

  const names = new Map<string, string>();
  for (const row of [...DEMO_SPX, ...DEMO_NDX, ...DEMO_EXPANDED]) {
    names.set(row.ticker, row.company);
  }

  const symbols: EngineSymbol[] = [];
  for (const [ticker, company] of names) {
    const rng = mulberry32(seedFromTicker(ticker));
    const start = 20 + rng() * 280;
    const drift = planted.has(ticker) ? 0.00085 : 0.00015 + rng() * 0.0005;
    const vol = planted.has(ticker) ? 0.008 : 0.007 + rng() * 0.012;
    let bars = geometricWalk(dates, start, drift, vol, rng);
    if (planted.has(ticker)) bars = applyLongPullbackTrigger(bars);
    symbols.push({
      ticker,
      company,
      exchange: "US",
      bars,
      inSpx: spxTickers.has(ticker),
      inNdx: ndxTickers.has(ticker),
    });
  }

  return {
    asOfDate,
    spy,
    symbols,
    spxTickers,
    ndxTickers,
    discovered: symbols.length + 4,
    rejected: 4,
  };
}
