/**
 * EODHD market-data provider.
 * The API token is read only on the server and never returned to the client.
 */

import { env } from "../env.server.ts";
import { lastCompletedWeekday, mergeBarRange, normalizeEodBar } from "../rglm/bars.ts";
import { BENCHMARK_EXCHANGE, BENCHMARK_TICKER, NDX_INDEX, PROVIDER_NAME, SPX_INDEX } from "../rglm/constants.ts";
import type { ApiStatus, DailyBar } from "../rglm/types.ts";
import { classifyInstrument, parseIndexComponents, type Classification } from "../universe/classify.ts";
import {
  backoffMs,
  canSpend,
  createBudget,
  recordFailure,
  recordSuccess,
  type BudgetState,
} from "./budget.ts";

const BASE = "https://eodhd.com/api";

export type ProviderLimits = {
  dailyLimit: number | null;
  requestsUsedHint: number | null;
  requestsUsedDate: string | null;
  remainingRequestHint: number | null;
  subscriptionType: string | null;
};

export type ProviderHealth = {
  provider: typeof PROVIDER_NAME;
  apiStatus: ApiStatus;
  tokenConfigured: boolean;
  message: string;
  latestProbeSession: string | null;
  limits: ProviderLimits;
};

function configuredToken(override?: string): string | undefined {
  const candidate = override?.trim();
  return candidate || env("EODHD_API_TOKEN");
}

function headerInt(res: Response, name: string): number | null {
  const v = res.headers.get(name);
  if (!v) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function remainingFrom(res: Response): number | null {
  return (
    headerInt(res, "x-ratelimit-remaining") ??
    headerInt(res, "x-rate-limit-remaining") ??
    headerInt(res, "ratelimit-remaining")
  );
}

function rateLimitFrom(res: Response): number | null {
  return (
    headerInt(res, "x-ratelimit-limit") ??
    headerInt(res, "x-rate-limit-limit") ??
    headerInt(res, "ratelimit-limit")
  );
}

function retryAfterMs(res: Response): number {
  const raw = res.headers.get("retry-after");
  if (!raw) return 0;
  const seconds = Number(raw);
  if (Number.isFinite(seconds) && seconds >= 0) return Math.min(30_000, seconds * 1000);
  const when = Date.parse(raw);
  if (!Number.isFinite(when)) return 0;
  return Math.min(30_000, Math.max(0, when - Date.now()));
}

function numberValue(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "") {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

export class EODHDMarketDataProvider {
  budget: BudgetState = createBudget();
  private readonly tokenOverride?: string;

  constructor(tokenOverride?: string) {
    this.tokenOverride = tokenOverride;
  }

  getProviderLimits(): ProviderLimits {
    return {
      dailyLimit: this.budget.dailyLimit,
      requestsUsedHint: this.budget.dailyCount,
      requestsUsedDate: this.budget.dailyDate,
      remainingRequestHint: this.budget.remainingRequestHint,
      subscriptionType: null,
    };
  }

  tokenConfigured(): boolean {
    return Boolean(configuredToken(this.tokenOverride));
  }

  private async request(
    path: string,
    extra: Record<string, string> = {},
    billing: { bulk?: boolean; apiCost?: number } = {},
  ): Promise<
    { ok: true; json: unknown; remaining: number | null } | { ok: false; status: number; kind: ApiStatus; message: string }
  > {
    const t = configuredToken(this.tokenOverride);
    if (!t) {
      return { ok: false, status: 0, kind: "NOT_CONFIGURED", message: "EODHD API token is not configured." };
    }
    const isBulk = billing.bulk === true;
    const apiCost = billing.apiCost ?? (isBulk ? 100 : 1);
    const spend = canSpend(this.budget, apiCost, 1);
    if (!spend.allowed) {
      return {
        ok: false,
        status: 429,
        kind: spend.reason === "RATE_LIMIT" ? "RATE_LIMITED" : "ERROR",
        message: `Request budget blocked: ${spend.reason}.`,
      };
    }

    const url = new URL(BASE + path);
    url.searchParams.set("api_token", t);
    url.searchParams.set("fmt", "json");
    for (const [k, v] of Object.entries(extra)) url.searchParams.set(k, v);

    let attempt = 0;
    while (attempt < 3) {
      attempt += 1;
      try {
        const res = await fetch(url.toString(), { headers: { Accept: "application/json" } });
        const remaining = remainingFrom(res);
        if (res.status === 429) {
          this.budget = recordFailure(this.budget, true);
          if (attempt >= 3) {
            return { ok: false, status: 429, kind: "RATE_LIMITED", message: "EODHD rate limited." };
          }
          const retryMs = retryAfterMs(res);
          await new Promise((r) => setTimeout(r, retryMs || backoffMs(attempt)));
          continue;
        }
        if (res.status === 402) {
          this.budget = recordFailure(this.budget, true);
          return { ok: false, status: 402, kind: "RATE_LIMITED", message: "EODHD daily API-call limit is exhausted." };
        }
        if (!res.ok) {
          this.budget = recordFailure(this.budget, false);
          const message =
            res.status === 401
              ? "EODHD rejected the API token (HTTP 401)."
              : `EODHD HTTP ${res.status}`;
          return { ok: false, status: res.status, kind: "ERROR", message };
        }
        const json: unknown = await res.json();
        this.budget = recordSuccess(
          this.budget,
          Date.now(),
          remaining,
          isBulk,
          apiCost,
          1,
          rateLimitFrom(res),
        );
        return { ok: true, json, remaining };
      } catch (err) {
        this.budget = recordFailure(this.budget, false);
        if (attempt >= 3) {
          return {
            ok: false,
            status: 0,
            kind: "ERROR",
            message: err instanceof Error ? err.message : "Network error",
          };
        }
        await new Promise((r) => setTimeout(r, backoffMs(attempt)));
      }
    }
    return { ok: false, status: 0, kind: "ERROR", message: "Request failed." };
  }

  async getDataStatus(): Promise<ProviderHealth> {
    if (!this.tokenConfigured()) {
      return {
        provider: PROVIDER_NAME,
        apiStatus: "NOT_CONFIGURED",
        tokenConfigured: false,
        message: "EODHD_API_TOKEN is not set. Live scans cannot run.",
        latestProbeSession: null,
        limits: this.getProviderLimits(),
      };
    }
    const user = await this.request("/user", {}, { apiCost: 0 });
    let limits = this.getProviderLimits();
    if (user.ok && user.json && typeof user.json === "object") {
      const row = user.json as Record<string, unknown>;
      limits = {
        dailyLimit: numberValue(row.dailyRateLimit) ?? limits.dailyLimit,
        requestsUsedHint: numberValue(row.apiRequests) ?? limits.requestsUsedHint,
        requestsUsedDate: typeof row.apiRequestsDate === "string" ? row.apiRequestsDate : limits.requestsUsedDate,
        remainingRequestHint: limits.remainingRequestHint,
        subscriptionType: typeof row.subscriptionType === "string" ? row.subscriptionType : null,
      };
      const dailyLimit = numberValue(row.dailyRateLimit);
      if (dailyLimit != null && dailyLimit > 0) this.budget.dailyLimit = dailyLimit;
      const apiRequests = numberValue(row.apiRequests);
      const apiRequestsDate = typeof row.apiRequestsDate === "string" ? row.apiRequestsDate : null;
      const todayUtc = new Date().toISOString().slice(0, 10);
      if (apiRequests != null && apiRequestsDate === todayUtc) {
        this.budget.dailyDate = apiRequestsDate;
        this.budget.dailyCount = Math.max(this.budget.dailyCount, apiRequests);
      }
    }
    const probe = await this.getLatestCompletedDailyBar(`${BENCHMARK_TICKER}.${BENCHMARK_EXCHANGE}`);
    if (!probe.ok) {
      return {
        provider: PROVIDER_NAME,
        apiStatus: probe.kind,
        tokenConfigured: true,
        message: probe.message,
        latestProbeSession: null,
        limits,
      };
    }
    return {
      provider: PROVIDER_NAME,
      apiStatus: "CONNECTED",
      tokenConfigured: true,
      message: "EODHD reachable.",
      latestProbeSession: probe.bar.date,
      limits,
    };
  }

  async getExchangeSymbols(
    exchange = "US",
  ): Promise<{ ok: true; rows: Classification[] } | { ok: false; kind: ApiStatus; message: string }> {
    const res = await this.request(`/exchange-symbol-list/${encodeURIComponent(exchange)}`, {
      type: "common_stock",
    });
    if (!res.ok) return { ok: false, kind: res.kind, message: res.message };
    if (!Array.isArray(res.json)) {
      return { ok: false, kind: "ERROR", message: "Unexpected exchange-symbol-list shape." };
    }
    const rows = res.json.map((row) => classifyInstrument(row as Record<string, unknown>));
    return { ok: true, rows };
  }

  async getIndexMembers(
    indexCode: string,
  ): Promise<
    | { ok: true; members: Array<{ ticker: string; company: string; exchange: string }> }
    | { ok: false; kind: ApiStatus; message: string }
  > {
    const res = await this.request(`/v1.1/fundamentals/${encodeURIComponent(indexCode)}`, { filter: "Components" });
    if (!res.ok) return { ok: false, kind: res.kind, message: res.message };
    const members = parseIndexComponents(res.json);
    if (members.length === 0) {
      return { ok: false, kind: "ERROR", message: `No constituents parsed for ${indexCode}.` };
    }
    return { ok: true, members };
  }

  async getHistoricalDailyBars(
    symbol: string,
    from?: string,
    to?: string,
  ): Promise<{ ok: true; bars: DailyBar[] } | { ok: false; kind: ApiStatus; message: string }> {
    const extra: Record<string, string> = { period: "d" };
    if (from) extra.from = from;
    if (to) extra.to = to;
    const res = await this.request(`/eod/${encodeURIComponent(symbol)}`, extra);
    if (!res.ok) return { ok: false, kind: res.kind, message: res.message };
    if (!Array.isArray(res.json)) {
      return { ok: false, kind: "ERROR", message: `Unexpected EOD shape for ${symbol}.` };
    }
    const bars: DailyBar[] = [];
    for (const row of res.json) {
      const n = normalizeEodBar(row as Record<string, unknown>);
      if (n) bars.push(n);
    }
    return { ok: true, bars: mergeBarRange([], bars) };
  }

  async getBulkDailyBars(
    exchange: string,
    date: string,
  ): Promise<{ ok: true; byTicker: Map<string, DailyBar> } | { ok: false; kind: ApiStatus; message: string }> {
    const res = await this.request(`/eod-bulk-last-day/${encodeURIComponent(exchange)}`, { date }, { bulk: true, apiCost: 100 });
    if (!res.ok) return { ok: false, kind: res.kind, message: res.message };
    if (!Array.isArray(res.json)) {
      return { ok: false, kind: "ERROR", message: "Unexpected bulk EOD shape." };
    }
    const byTicker = new Map<string, DailyBar>();
    for (const row of res.json) {
      if (!row || typeof row !== "object") continue;
      const rec = row as Record<string, unknown>;
      const code = String(rec.code ?? rec.Code ?? "").toUpperCase();
      const n = normalizeEodBar(rec);
      if (code && n) byTicker.set(code, n);
    }
    return { ok: true, byTicker };
  }

  async getLatestCompletedDailyBar(
    symbol: string,
  ): Promise<{ ok: true; bar: DailyBar } | { ok: false; kind: ApiStatus; message: string }> {
    const to = lastCompletedWeekday();
    const from = new Date(`${to}T00:00:00Z`);
    from.setUTCDate(from.getUTCDate() - 21);
    const res = await this.getHistoricalDailyBars(symbol, from.toISOString().slice(0, 10), to);
    if (!res.ok) return res;
    const bar = res.bars[res.bars.length - 1];
    if (!bar) return { ok: false, kind: "ERROR", message: `No bars for ${symbol}.` };
    return { ok: true, bar };
  }

  async getSpyHistory(): Promise<{ ok: true; bars: DailyBar[] } | { ok: false; kind: ApiStatus; message: string }> {
    // RGLM only needs a finite lookback. Avoid downloading years of history on every
    // status/scan call while still leaving enough calendar room for 320+ sessions.
    const to = lastCompletedWeekday();
    const from = new Date(`${to}T00:00:00Z`);
    from.setUTCDate(from.getUTCDate() - 500);
    return this.getHistoricalDailyBars(
      `${BENCHMARK_TICKER}.${BENCHMARK_EXCHANGE}`,
      from.toISOString().slice(0, 10),
      to,
    );
  }

  async getSpxAndNdx(): Promise<
    | {
        ok: true;
        spx: Array<{ ticker: string; company: string; exchange: string }>;
        ndx: Array<{ ticker: string; company: string; exchange: string }>;
      }
    | { ok: false; kind: ApiStatus; message: string; reason: "INDEX_DATA_UNAVAILABLE" }
  > {
    const spx = await this.getIndexMembers(SPX_INDEX);
    if (!spx.ok) {
      return { ok: false, kind: spx.kind, message: spx.message, reason: "INDEX_DATA_UNAVAILABLE" };
    }
    const ndx = await this.getIndexMembers(NDX_INDEX);
    if (!ndx.ok) {
      return { ok: false, kind: ndx.kind, message: ndx.message, reason: "INDEX_DATA_UNAVAILABLE" };
    }
    return { ok: true, spx: spx.members, ndx: ndx.members };
  }
}

export function createProvider(tokenOverride?: string): EODHDMarketDataProvider {
  return new EODHDMarketDataProvider(tokenOverride);
}
