import assert from "node:assert/strict";
import { test } from "node:test";
import { canSpend, createBudget, recordSuccess } from "./budget.ts";

test("bulk API cost is separate from HTTP request rate", () => {
  let state = createBudget();
  state = recordSuccess(state, Date.now(), 999, true, 100, 1, 1000);
  assert.equal(state.dailyCount, 100);
  assert.equal(state.windowCount, 1);
  assert.equal(state.remainingRequestHint, 999);
  assert.equal(canSpend(state, 100, 1).allowed, true);
});

test("daily API-call budget blocks a request only when its cost exceeds the remaining daily calls", () => {
  const state = {
    ...createBudget(),
    dailyLimit: 20,
    dailyCount: 19,
  };
  assert.equal(canSpend(state, 1, 1).allowed, true);
  assert.equal(canSpend(state, 2, 1).reason, "DAILY_LIMIT");
});
