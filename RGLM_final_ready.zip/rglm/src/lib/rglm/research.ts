/**
 * Research stop, 3R target, and theoretical position size.
 * These are research levels only — never execution prices.
 */

import {
  ATR_PERIOD,
  ATR_STOP_MULT,
  MAX_ALLOCATION_PCT,
  RESEARCH_CAPITAL,
  RESEARCH_RISK_BUDGET,
  SWING_LOOKBACK,
  TARGET_R_MULT,
} from "./constants.ts";
import { calculateATR, isFiniteNumber } from "./indicators.ts";
import type { DailyBar, Direction, ResearchLevels } from "./types.ts";

export function swingLow(bars: readonly DailyBar[], index: number, lookback = SWING_LOOKBACK): number | null {
  const start = index - lookback;
  if (start < 0) return null;
  let m = Infinity;
  for (let i = start; i <= index - 1; i++) {
    const v = bars[i]?.low;
    if (!isFiniteNumber(v)) return null;
    if (v < m) m = v;
  }
  return Number.isFinite(m) ? m : null;
}

export function swingHigh(bars: readonly DailyBar[], index: number, lookback = SWING_LOOKBACK): number | null {
  const start = index - lookback;
  if (start < 0) return null;
  let m = -Infinity;
  for (let i = start; i <= index - 1; i++) {
    const v = bars[i]?.high;
    if (!isFiniteNumber(v)) return null;
    if (v > m) m = v;
  }
  return Number.isFinite(m) ? m : null;
}

export function calculateResearchLevels(
  bars: readonly DailyBar[],
  index: number,
  direction: Direction,
): ResearchLevels | null {
  const entry = bars[index]?.close;
  const atr = calculateATR(bars, ATR_PERIOD, index);
  if (!isFiniteNumber(entry) || !isFiniteNumber(atr) || atr <= 0) return null;

  let stop: number;
  let atrStop: number;
  let swingLevel: number | null;

  if (direction === "LONG") {
    atrStop = entry - ATR_STOP_MULT * atr;
    swingLevel = swingLow(bars, index);
    if (!isFiniteNumber(swingLevel)) return null;
    stop = Math.min(atrStop, swingLevel);
  } else {
    atrStop = entry + ATR_STOP_MULT * atr;
    swingLevel = swingHigh(bars, index);
    if (!isFiniteNumber(swingLevel)) return null;
    stop = Math.max(atrStop, swingLevel);
  }

  const rValue = Math.abs(entry - stop);
  if (!isFiniteNumber(rValue) || rValue <= 0) return null;
  if (direction === "LONG" && stop >= entry) return null;
  if (direction === "SHORT" && stop <= entry) return null;

  const target3R = direction === "LONG" ? entry + TARGET_R_MULT * rValue : entry - TARGET_R_MULT * rValue;

  let theoreticalQuantity = RESEARCH_RISK_BUDGET / rValue;
  let theoreticalAllocation = theoreticalQuantity * entry;
  let allocationCapped = false;
  const maxAlloc = RESEARCH_CAPITAL * MAX_ALLOCATION_PCT;
  if (theoreticalAllocation > maxAlloc) {
    theoreticalQuantity = maxAlloc / entry;
    theoreticalAllocation = maxAlloc;
    allocationCapped = true;
  }
  if (!isFiniteNumber(theoreticalQuantity) || theoreticalQuantity <= 0) return null;

  return {
    referenceEntry: entry,
    stop,
    target3R,
    rValue,
    atrStop,
    swingLevel,
    theoreticalRiskBudget: RESEARCH_RISK_BUDGET,
    theoreticalQuantity,
    theoreticalAllocation,
    allocationCapped,
  };
}
