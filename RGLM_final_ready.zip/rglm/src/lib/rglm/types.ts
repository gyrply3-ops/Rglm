export type Direction = "LONG" | "SHORT";
export type MarketRegime = "TREND_UP" | "TREND_DOWN" | "TRANSITION";
export type ScanStatus = "TRADE" | "NO_TRADE";
export type CoverageStatus = "COMPLETE" | "PARTIAL" | "INSUFFICIENT" | "UNKNOWN";
export type DataStatus = "LIVE" | "DEMO" | "ERROR" | "NOT_CONFIGURED";
export type UniverseMode = "PRODUCTION" | "DEMO_RESEARCH";
export type ApiStatus = "CONNECTED" | "NOT_CONFIGURED" | "ERROR" | "RATE_LIMITED";
export type VolatilityState = "ACCEPTABLE" | "VOLATILITY_STRESS" | "UNAVAILABLE";
export type ClassificationStatus = "ELIGIBLE" | "REJECTED" | "UNKNOWN";

export type ReasonCode =
  | "TRADE_SIGNAL"
  | "TRANSITION_MARKET"
  | "VOLATILITY_STRESS"
  | "BENCHMARK_DATA_UNAVAILABLE"
  | "DATA_QUALITY_FAILURE"
  | "INSUFFICIENT_HISTORY"
  | "INSUFFICIENT_MARKET_COVERAGE"
  | "INDEX_DATA_UNAVAILABLE"
  | "NO_HARD_GATE_SURVIVORS"
  | "NO_QUALIFIED_CANDIDATES"
  | "DATA_LIMITATION"
  | "DATA_ERROR"
  | "RATE_LIMITED"
  | "API_NOT_CONFIGURED"
  | "STALE_DATA"
  | "INVALID_RESEARCH_STOP";

export type DailyBar = {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type GateName =
  | "dataQuality"
  | "minimumHistory"
  | "marketRegime"
  | "volatility"
  | "assetTrend"
  | "relativeStrength"
  | "pullback"
  | "trigger";

export type GateResult = {
  name: GateName;
  passed: boolean;
  detail: string;
};

export type ScoreBreakdown = {
  trend: number;
  relativeStrength: number;
  pullback: number;
  volatility: number;
  trigger: number;
  total: number;
  trendPriceDistance: number;
  trendSmaDistance: number;
  rsExcess: number;
  pullbackDistance: number;
  volRatio: number;
  triggerStrengthAtr: number;
};

export type PullbackMetrics = {
  recentExtreme: number;
  distance: number;
  touched: boolean;
  closeVsSma20: number;
  valid: boolean;
};

export type ResearchLevels = {
  referenceEntry: number;
  stop: number;
  target3R: number;
  rValue: number;
  atrStop: number;
  swingLevel: number;
  theoreticalRiskBudget: number;
  theoreticalQuantity: number;
  theoreticalAllocation: number;
  allocationCapped: boolean;
};

export type CandidateMetrics = {
  ticker: string;
  company: string;
  exchange: string;
  direction: Direction;
  close: number;
  sma20: number;
  sma50: number;
  sma200: number;
  atr20: number;
  volRatio: number;
  return63: number;
  spyReturn63: number;
  excess63: number;
  prevHigh: number;
  prevLow: number;
  pullback: PullbackMetrics;
  triggerPassed: boolean;
  triggerStrengthAtr: number;
  gates: GateResult[];
  passedHardGates: boolean;
  score: ScoreBreakdown | null;
  research: ResearchLevels | null;
  inSpx: boolean;
  inNdx: boolean;
  barCount: number;
  lastDate: string;
};

export type WinnerCard = {
  ticker: string;
  company: string;
  direction: Direction;
  score: number;
  currentPrice: number;
  referenceEntry: number;
  stop: number;
  target3R: number;
  theoreticalRiskBudget: number;
  theoreticalPositionSize: number;
  theoreticalQuantity: number;
  allocationCapped: boolean;
  relativeStrength: number;
  excess63: number;
  return63: number;
  spyReturn63: number;
  inSpx: boolean;
  inNdx: boolean;
};

export type ScanStatistics = {
  universeDiscovered: number;
  universeEligible: number;
  universeRejected: number;
  dataQualityRejects: number;
  insufficientHistoryRejects: number;
  hardGateSurvivors: number;
  scoreQualified: number;
  finalCandidate: string | null;
  spxFound: number;
  spxExpected: number;
  ndxFound: number;
  ndxExpected: number;
  expandedUniverse: number;
  uniqueEligible: number;
  cacheHits: number;
  providerRequests: number;
  elapsedMs: number;
};

export type SpyState = {
  lastDate: string;
  close: number;
  sma20: number | null;
  sma50: number | null;
  sma200: number | null;
  atr20: number | null;
  return63: number | null;
  volRatio: number | null;
  volThreshold: number | null;
  regime: MarketRegime | "UNAVAILABLE";
  volatilityState: VolatilityState;
  barCount: number;
  valid: boolean;
  failReason: string | null;
};

export type ChartPoint = {
  date: string;
  close: number;
  sma20: number | null;
  sma50: number | null;
  sma200: number | null;
  high20: number | null;
  low20: number | null;
};

export type RglmResult = {
  strategyVersion: "RGLM-v0.1";
  status: ScanStatus;
  reasonCode: ReasonCode;
  reasonText: string;
  timestamp: string;
  dataSnapshotId: string;
  marketRegime: MarketRegime | "UNAVAILABLE";
  volatilityStress: boolean;
  volatilityState: VolatilityState;
  spyVolRatio: number | null;
  spyVolThreshold: number | null;
  universeCount: number;
  eligibleCount: number;
  hardGateSurvivors: number;
  qualifiedCount: number;
  coverageStatus: CoverageStatus;
  dataStatus: DataStatus;
  universeMode: UniverseMode;
  universeKind: "CURRENT_CONSTITUENT_UNIVERSE";
  provider: "EODHD";
  latestCompletedSession: string | null;
  winner: WinnerCard | null;
  scoreBreakdown: ScoreBreakdown | null;
  reasons: string[];
  scanStatistics: ScanStatistics;
  spy: SpyState;
  checklist: GateResult[];
  rankedQualified: Array<{
    ticker: string;
    company: string;
    direction: Direction;
    score: number;
    breakdown: ScoreBreakdown;
  }>;
  rejectedHighScores: Array<{
    ticker: string;
    company: string;
    direction: Direction | null;
    failedGates: string[];
    detail: string;
  }>;
  chart: ChartPoint[];
  researchDisclaimer: string;
};

export type EngineSymbol = {
  ticker: string;
  company: string;
  exchange: string;
  bars: DailyBar[];
  inSpx: boolean;
  inNdx: boolean;
};

export type EngineInput = {
  spyBars: DailyBar[];
  symbols: EngineSymbol[];
  asOfDate: string | null;
  timestamp: string;
  dataSnapshotId: string;
  dataStatus: DataStatus;
  universeMode: UniverseMode;
  coverageStatus: CoverageStatus;
  coverageReason?: string;
  universeDiscovered: number;
  universeRejected: number;
  spxFound: number;
  spxExpected: number;
  ndxFound: number;
  ndxExpected: number;
  cacheHits: number;
  providerRequests: number;
  elapsedMs: number;
};
