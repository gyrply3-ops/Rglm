import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  applyLongPullbackTrigger,
  applyShortPullbackTrigger,
  geometricWalk,
  makeBar,
  mulberry32,
  weekdaySessionsEnding,
} from "./bars.ts";
import {
  assetTrend,
  calculateATR,
  calculateGlobalVolatility,
  calculateMarketRegime,
  calculatePullback,
  calculateReturn,
  calculateSMA,
  calculateTrigger,
  percentile,
  pullbackQualityScore,
  relativeStrengthScore,
  trendQualityScore,
  triggerQualityScore,
  trueRange,
  volatilityQualityScores,
} from "./indicators.ts";
import type { DailyBar } from "./types.ts";

function series(n: number, start = 100, step = 1): DailyBar[] {
  const dates = weekdaySessionsEnding("2024-12-31", n);
  return dates.map((date, i) => makeBar(date, start + i * step, 0.005));
}

describe("SMA", () => {
  it("computes SMA20/50/200 on a linear series", () => {
    const bars = series(220, 10, 1);
    const values = bars.map((b) => b.close);
    const i = values.length - 1;
    const sma20 = calculateSMA(values, 20, i);
    const sma50 = calculateSMA(values, 50, i);
    const sma200 = calculateSMA(values, 200, i);
    assert.ok(sma20);
    assert.ok(sma50);
    assert.ok(sma200);
    const last = values[i]!;
    assert.equal(sma20, last - 9.5);
    assert.equal(sma50, last - 24.5);
    assert.equal(sma200, last - 99.5);
  });

  it("returns null until the window is full", () => {
    assert.equal(calculateSMA([1, 2, 3], 20, 2), null);
  });
});

describe("ATR20", () => {
  it("matches Wilder ATR on a hand-computed series", () => {
    const dates = weekdaySessionsEnding("2024-06-28", 25);
    const bars: DailyBar[] = dates.map((date, i) => {
      const close = 100 + i;
      return {
        date,
        open: close,
        high: close + 2,
        low: close - 2,
        close,
        volume: 1000,
      };
    });
    const atr = calculateATR(bars, 20, 24);
    assert.ok(atr);
    // TR[i>=1] = max(4, |(c+2)-(c-1)|, |(c-2)-(c-1)|) = max(4, 3, 3) = 4
    // First ATR = 4; subsequent remain 4.
    assert.ok(Math.abs(atr - 4) < 1e-12);
  });

  it("uses previous close in true range", () => {
    const bars: DailyBar[] = [
      makeBar("2024-01-02", 100, 0.01),
      { date: "2024-01-03", open: 110, high: 112, low: 109, close: 111, volume: 1 },
    ];
    const tr = trueRange(bars, 1);
    assert.equal(tr, Math.max(3, 12, 9));
  });
});

describe("regime", () => {
  it("TREND_UP when close and SMA50 are above SMA200", () => {
    assert.equal(calculateMarketRegime(110, 108, 100), "TREND_UP");
  });
  it("TREND_DOWN when close and SMA50 are below SMA200", () => {
    assert.equal(calculateMarketRegime(90, 92, 100), "TREND_DOWN");
  });
  it("TRANSITION otherwise", () => {
    assert.equal(calculateMarketRegime(110, 90, 100), "TRANSITION");
    assert.equal(calculateMarketRegime(90, 110, 100), "TRANSITION");
    assert.equal(calculateMarketRegime(100, 100, 100), "TRANSITION");
  });
  it("asset trend matches the same rules", () => {
    assert.equal(assetTrend(110, 108, 100), "LONG");
    assert.equal(assetTrend(90, 92, 100), "SHORT");
    assert.equal(assetTrend(110, 90, 100), null);
  });
});

describe("returns and relative strength", () => {
  it("computes a 63-day return", () => {
    const values = Array.from({ length: 70 }, (_, i) => 100 + i);
    const r = calculateReturn(values, 63, 69);
    assert.ok(r);
    assert.ok(Math.abs(r - (169 / 106 - 1)) < 1e-12);
  });
  it("long RS requires asset > SPY; short requires asset < SPY", () => {
    assert.ok(relativeStrengthScore(0.1) === 25);
    assert.equal(relativeStrengthScore(0), 0);
    assert.equal(relativeStrengthScore(-0.02), 0);
    assert.ok(Math.abs(relativeStrengthScore(0.05) - 12.5) < 1e-12);
  });
});

describe("volatility percentile", () => {
  it("excludes the current observation", () => {
    const dates = weekdaySessionsEnding("2025-06-30", 320);
    const rng = mulberry32(7);
    const bars = geometricWalk(dates, 400, 0.0003, 0.01, rng);
    const i = bars.length - 1;
    const vol = calculateGlobalVolatility(bars, i);
    assert.equal(vol.available, true);
    assert.ok(vol.ratio != null);
    assert.ok(vol.threshold != null);
    const future = bars.map((b) => ({ ...b }));
    future.push({
      date: "2099-01-01",
      open: 1e9,
      high: 1e9,
      low: 1e9,
      close: 1e9,
      volume: 1,
    });
    const vol2 = calculateGlobalVolatility(future, i);
    assert.equal(vol.ratio, vol2.ratio);
    assert.equal(vol.threshold, vol2.threshold);
    assert.equal(vol.stress, vol2.stress);
  });

  it("flags stress when current ratio exceeds the 90th percentile", () => {
    const dates = weekdaySessionsEnding("2025-06-30", 320);
    const bars = dates.map((date) => makeBar(date, 100, 0.01));
    const i = bars.length - 1;
    bars[i] = {
      date: bars[i]!.date,
      open: 100,
      high: 180,
      low: 20,
      close: 100,
      volume: 1_000_000,
    };
    const vol = calculateGlobalVolatility(bars, i);
    assert.equal(vol.available, true);
    assert.equal(vol.stress, true);
  });

  it("percentile interpolates", () => {
    assert.equal(percentile([0, 10], 90), 9);
    assert.equal(percentile([], 90), null);
  });
});

describe("pullback", () => {
  it("accepts the 2% and 6% boundaries and scores 3-4% as ideal", () => {
    assert.equal(pullbackQualityScore(0.02), 0);
    assert.equal(pullbackQualityScore(0.06), 0);
    assert.equal(pullbackQualityScore(0.035), 20);
    assert.equal(pullbackQualityScore(0.03), 20);
    assert.equal(pullbackQualityScore(0.04), 20);
    assert.ok(pullbackQualityScore(0.025) > 0 && pullbackQualityScore(0.025) < 20);
    assert.equal(pullbackQualityScore(0.019), 0);
    assert.equal(pullbackQualityScore(0.061), 0);
  });

  it("long pullback uses previous-20 high excluding current, with a 10-day touch", () => {
    const dates = weekdaySessionsEnding("2024-12-31", 40);
    let bars = dates.map((d) => makeBar(d, 100, 0.002));
    bars = applyLongPullbackTrigger(bars);
    const i = bars.length - 1;
    const pb = calculatePullback(bars, i, "LONG", 90);
    assert.equal(pb.valid, true);
    assert.ok(pb.distance >= 0.02 && pb.distance <= 0.06);
    assert.equal(pb.touched, true);
    const highNow = bars[i]!.high;
    const recent = Math.max(...bars.slice(i - 20, i).map((b) => b.high));
    assert.ok(highNow <= recent + 1e-9);
  });

  it("short pullback uses previous-20 low excluding current", () => {
    const dates = weekdaySessionsEnding("2024-12-31", 40);
    let bars = dates.map((d) => makeBar(d, 100, 0.002));
    bars = applyShortPullbackTrigger(bars);
    const i = bars.length - 1;
    const pb = calculatePullback(bars, i, "SHORT", 200);
    assert.equal(pb.valid, true);
    assert.equal(pb.touched, true);
  });
});

describe("trigger", () => {
  it("long trigger is close > previous high", () => {
    const bars: DailyBar[] = [
      ...series(25, 100, 0),
    ];
    const i = bars.length - 1;
    bars[i - 1] = { ...bars[i - 1]!, high: 100, low: 99, close: 99.5, open: 99.5 };
    bars[i] = { ...bars[i]!, close: 101, high: 101.2, low: 100, open: 100.2 };
    const t = calculateTrigger(bars, i, "LONG");
    assert.equal(t.passed, true);
  });
  it("short trigger is close < previous low", () => {
    const bars = series(25, 100, 0);
    const i = bars.length - 1;
    bars[i - 1] = { ...bars[i - 1]!, high: 101, low: 100, close: 100.5, open: 100.5 };
    bars[i] = { ...bars[i]!, close: 99, high: 100, low: 98.5, open: 99.8 };
    const t = calculateTrigger(bars, i, "SHORT");
    assert.equal(t.passed, true);
  });
});

describe("scores", () => {
  it("caps trend quality at 25", () => {
    const s = trendQualityScore(200, 180, 100, "LONG");
    assert.equal(s.score, 25);
  });
  it("caps trigger quality at 15", () => {
    assert.equal(triggerQualityScore(3), 15);
    assert.equal(triggerQualityScore(0), 0);
    assert.equal(triggerQualityScore(0.5), 7.5);
  });
  it("normalizes volatility without NaN or divide-by-zero", () => {
    assert.deepEqual(volatilityQualityScores([0.02, 0.02, 0.02]), [15, 15, 15]);
    const mixed = volatilityQualityScores([0.01, 0.02, 0.03]);
    assert.equal(mixed[0], 15);
    assert.equal(mixed[2], 0);
    assert.ok(mixed.every((x) => Number.isFinite(x)));
    assert.deepEqual(volatilityQualityScores([]), []);
  });
});
