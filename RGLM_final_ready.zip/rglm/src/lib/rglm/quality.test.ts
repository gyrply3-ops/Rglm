import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { makeBar, weekdaySessionsEnding } from "./bars.ts";
import { validateRGLMData } from "./quality.ts";

function validSeries(n = 252) {
  const dates = weekdaySessionsEnding("2024-12-31", n);
  return dates.map((d, i) => makeBar(d, 50 + i * 0.01));
}

describe("validateRGLMData", () => {
  it("passes a clean 252-session series", () => {
    const r = validateRGLMData(validSeries(252), "2024-12-31");
    assert.equal(r.ok, true);
  });
  it("rejects insufficient history", () => {
    const r = validateRGLMData(validSeries(100), "2024-12-31");
    assert.equal(r.ok, false);
    assert.ok(r.issues.some((i) => i.code === "INSUFFICIENT_HISTORY"));
  });
  it("rejects invalid OHLC", () => {
    const bars = validSeries(252);
    bars[10] = { ...bars[10]!, high: 1, low: 2, close: 1.5, open: 1.5 };
    const r = validateRGLMData(bars, "2024-12-31");
    assert.equal(r.ok, false);
    assert.ok(r.issues.some((i) => i.code === "HIGH_LT_LOW"));
  });
  it("rejects close outside high/low", () => {
    const bars = validSeries(252);
    bars[11] = { ...bars[11]!, high: 10, low: 9, open: 9.5, close: 12 };
    const r = validateRGLMData(bars, "2024-12-31");
    assert.ok(r.issues.some((i) => i.code === "CLOSE_OUTSIDE_RANGE"));
  });
  it("rejects duplicate dates", () => {
    const bars = validSeries(252);
    bars[5] = { ...bars[5]!, date: bars[4]!.date };
    const r = validateRGLMData(bars, "2024-12-31");
    assert.ok(r.issues.some((i) => i.code === "DUPLICATE_DATES"));
  });
  it("rejects missing volume", () => {
    const bars = validSeries(252);
    bars[6] = { ...bars[6]!, volume: Number.NaN };
    const r = validateRGLMData(bars, "2024-12-31");
    assert.ok(r.issues.some((i) => i.code === "MISSING_VOLUME"));
  });
  it("rejects stale data", () => {
    const bars = validSeries(252);
    const r = validateRGLMData(bars, "2025-06-01");
    assert.ok(r.issues.some((i) => i.code === "STALE_DATA"));
  });
  it("rejects non-positive prices", () => {
    const bars = validSeries(252);
    bars[8] = { ...bars[8]!, open: -1, high: 2, low: -2, close: 1 };
    const r = validateRGLMData(bars, "2024-12-31");
    assert.ok(r.issues.some((i) => i.code === "NON_POSITIVE_PRICE"));
  });
});
