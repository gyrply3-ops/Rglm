/**
 * Deterministic RGLM indicator library.
 *
 * Pure functions. No I/O, no randomness, no look-ahead: every rolling window
 * is aligned to an explicit `index` and never reads bars after that index.
 *
 * SMA(n) at i = mean(close[i-n+1] .. close[i]) inclusive of the completed bar.
 *
 * ATR(n) is Wilder ATR:
 *   TR[i] = max(high-low, |high-prevClose|, |low-prevClose|) for i >= 1
 *   ATR[n] = mean(TR[1] .. TR[n])          //  n true ranges
 *   ATR[i] = (ATR[i-1] * (n-1) + TR[i]) / n
 *
 * 63-day return at i = close[i] / close[i-63] - 1
 */

import {
  ATR_PERIOD,
  PULLBACK_IDEAL_HIGH,
  PULLBACK_IDEAL_LOW,
  PULLBACK_LOOKBACK,
  PULLBACK_MAX,
  PULLBACK_MIN,
  PULLBACK_TOUCH_LOOKBACK,
  RETURN_HORIZON,
  RS_FULL_EXCESS,
  SCORE_PULLBACK_MAX,
  SCORE_RS_MAX,
  SCORE_TREND_MAX,
  SCORE_TRIGGER_MAX,
  SMA_FAST,
  SMA_MID,
  SMA_SLOW,
  TREND_FULL_DISTANCE,
  TRIGGER_FULL_ATR,
  VOL_LOOKBACK,
  VOL_PERCENTILE,
} from "./constants.ts";
import type { DailyBar, Direction, MarketRegime, PullbackMetrics } from "./types.ts";

export function isFiniteNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

export function calculateSMA(values: readonly number[], period: number, index: number): number | null {
  if (period <= 0 || index < period - 1 || index >= values.length) return null;
  let sum = 0;
  for (let i = index - period + 1; i <= index; i++) {
    const v = values[i];
    if (!isFiniteNumber(v)) return null;
    sum += v;
  }
  return sum / period;
}

export function trueRange(bars: readonly DailyBar[], index: number): number | null {
  const bar = bars[index];
  if (!bar) return null;
  const range = bar.high - bar.low;
  if (index === 0) return range;
  const prev = bars[index - 1];
  if (!prev) return null;
  return Math.max(range, Math.abs(bar.high - prev.close), Math.abs(bar.low - prev.close));
}

export function calculateATR(bars: readonly DailyBar[], period: number, index: number): number | null {
  if (period <= 0 || index < period || index >= bars.length) return null;
  const firstEnd = period;
  let atr = 0;
  for (let i = 1; i <= firstEnd; i++) {
    const tr = trueRange(bars, i);
    if (!isFiniteNumber(tr)) return null;
    atr += tr;
  }
  atr /= period;
  for (let i = firstEnd + 1; i <= index; i++) {
    const tr = trueRange(bars, i);
    if (!isFiniteNumber(tr)) return null;
    atr = (atr * (period - 1) + tr) / period;
  }
  return atr;
}

export function calculateReturn(values: readonly number[], horizon: number, index: number): number | null {
  const prior = index - horizon;
  if (prior < 0 || index >= values.length) return null;
  const now = values[index];
  const then = values[prior];
  if (!isFiniteNumber(now) || !isFiniteNumber(then) || then === 0) return null;
  return now / then - 1;
}

/** Linear-interpolation percentile. `p` in [0, 100]. Empty input returns null. */
export function percentile(values: readonly number[], p: number): number | null {
  if (values.length === 0 || !isFiniteNumber(p)) return null;
  const sorted = values.filter(isFiniteNumber).slice().sort((a, b) => a - b);
  if (sorted.length === 0) return null;
  const idx = (p / 100) * (sorted.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return sorted[lo]!;
  const w = idx - lo;
  return sorted[lo]! * (1 - w) + sorted[hi]! * w;
}

export function closesOf(bars: readonly DailyBar[]): number[] {
  return bars.map((b) => b.close);
}

export function calculateMarketRegime(
  close: number | null,
  sma50: number | null,
  sma200: number | null,
): MarketRegime | "UNAVAILABLE" {
  if (!isFiniteNumber(close) || !isFiniteNumber(sma50) || !isFiniteNumber(sma200)) {
    return "UNAVAILABLE";
  }
  if (close > sma200 && sma50 > sma200) return "TREND_UP";
  if (close < sma200 && sma50 < sma200) return "TREND_DOWN";
  return "TRANSITION";
}

export function assetTrend(
  close: number | null,
  sma50: number | null,
  sma200: number | null,
): Direction | null {
  if (!isFiniteNumber(close) || !isFiniteNumber(sma50) || !isFiniteNumber(sma200)) return null;
  if (close > sma200 && sma50 > sma200) return "LONG";
  if (close < sma200 && sma50 < sma200) return "SHORT";
  return null;
}

/**
 * Volatility ratio ATR/Close. Threshold is the `VOL_PERCENTILE` of the
 * PREVIOUS `VOL_LOOKBACK` completed sessions — current observation excluded.
 */
export function calculateGlobalVolatility(
  bars: readonly DailyBar[],
  index: number,
): { ratio: number | null; threshold: number | null; stress: boolean; available: boolean } {
  const atr = calculateATR(bars, ATR_PERIOD, index);
  const close = bars[index]?.close;
  if (!isFiniteNumber(atr) || !isFiniteNumber(close) || close === 0) {
    return { ratio: null, threshold: null, stress: false, available: false };
  }
  const ratio = atr / close;
  const hist: number[] = [];
  for (let j = index - VOL_LOOKBACK; j < index; j++) {
    if (j < 0) return { ratio, threshold: null, stress: false, available: false };
    const a = calculateATR(bars, ATR_PERIOD, j);
    const c = bars[j]?.close;
    if (!isFiniteNumber(a) || !isFiniteNumber(c) || c === 0) {
      return { ratio, threshold: null, stress: false, available: false };
    }
    hist.push(a / c);
  }
  if (hist.length !== VOL_LOOKBACK) {
    return { ratio, threshold: null, stress: false, available: false };
  }
  const threshold = percentile(hist, VOL_PERCENTILE);
  if (!isFiniteNumber(threshold)) {
    return { ratio, threshold: null, stress: false, available: false };
  }
  return { ratio, threshold, stress: ratio > threshold, available: true };
}

export function recentHigh(bars: readonly DailyBar[], index: number, lookback = PULLBACK_LOOKBACK): number | null {
  const start = index - lookback;
  if (start < 0 || index - 1 >= bars.length) return null;
  let m = -Infinity;
  for (let i = start; i <= index - 1; i++) {
    const h = bars[i]?.high;
    if (!isFiniteNumber(h)) return null;
    if (h > m) m = h;
  }
  return Number.isFinite(m) ? m : null;
}

export function recentLow(bars: readonly DailyBar[], index: number, lookback = PULLBACK_LOOKBACK): number | null {
  const start = index - lookback;
  if (start < 0 || index - 1 >= bars.length) return null;
  let m = Infinity;
  for (let i = start; i <= index - 1; i++) {
    const l = bars[i]?.low;
    if (!isFiniteNumber(l)) return null;
    if (l < m) m = l;
  }
  return Number.isFinite(m) ? m : null;
}

export function touchedExtreme(
  bars: readonly DailyBar[],
  index: number,
  extreme: number,
  side: Direction,
  lookback = PULLBACK_TOUCH_LOOKBACK,
): boolean {
  const start = index - lookback;
  if (start < 0) return false;
  for (let i = start; i <= index - 1; i++) {
    if (side === "LONG") {
      if (bars[i]!.high >= extreme) return true;
    } else if (bars[i]!.low <= extreme) return true;
  }
  return false;
}

export function calculatePullback(
  bars: readonly DailyBar[],
  index: number,
  direction: Direction,
  sma20: number | null,
): PullbackMetrics {
  const close = bars[index]?.close;
  const invalid: PullbackMetrics = {
    recentExtreme: NaN,
    distance: NaN,
    touched: false,
    closeVsSma20: NaN,
    valid: false,
  };
  if (!isFiniteNumber(close) || !isFiniteNumber(sma20)) return invalid;

  if (direction === "LONG") {
    const hi = recentHigh(bars, index);
    if (!isFiniteNumber(hi) || hi === 0) return invalid;
    const distance = (hi - close) / hi;
    const touched = touchedExtreme(bars, index, hi, "LONG");
    const valid = distance >= PULLBACK_MIN && distance <= PULLBACK_MAX && touched && close > sma20;
    return { recentExtreme: hi, distance, touched, closeVsSma20: close - sma20, valid };
  }

  const lo = recentLow(bars, index);
  if (!isFiniteNumber(lo) || lo === 0) return invalid;
  const distance = (close - lo) / lo;
  const touched = touchedExtreme(bars, index, lo, "SHORT");
  const valid = distance >= PULLBACK_MIN && distance <= PULLBACK_MAX && touched && close < sma20;
  return { recentExtreme: lo, distance, touched, closeVsSma20: close - sma20, valid };
}

export function calculateTrigger(
  bars: readonly DailyBar[],
  index: number,
  direction: Direction,
): { passed: boolean; strengthAtr: number; prevHigh: number | null; prevLow: number | null } {
  const close = bars[index]?.close;
  const prev = bars[index - 1];
  const atr = calculateATR(bars, ATR_PERIOD, index);
  const prevHigh = prev?.high ?? null;
  const prevLow = prev?.low ?? null;
  if (!isFiniteNumber(close) || !prev) {
    return { passed: false, strengthAtr: 0, prevHigh, prevLow };
  }
  if (direction === "LONG") {
    const passed = close > prev.high;
    const strengthAtr = passed && isFiniteNumber(atr) && atr > 0 ? (close - prev.high) / atr : 0;
    return { passed, strengthAtr, prevHigh, prevLow };
  }
  const passed = close < prev.low;
  const strengthAtr = passed && isFiniteNumber(atr) && atr > 0 ? (prev.low - close) / atr : 0;
  return { passed, strengthAtr, prevHigh, prevLow };
}

export function capScore(value: number, max: number): number {
  if (!isFiniteNumber(value) || value <= 0) return 0;
  return Math.min(max, value);
}

export function trendQualityScore(
  close: number,
  sma50: number,
  sma200: number,
  direction: Direction,
): { score: number; priceDistance: number; smaDistance: number } {
  if (sma200 === 0) return { score: 0, priceDistance: 0, smaDistance: 0 };
  const priceDistance =
    direction === "LONG" ? (close - sma200) / sma200 : (sma200 - close) / sma200;
  const smaDistance =
    direction === "LONG" ? (sma50 - sma200) / sma200 : (sma200 - sma50) / sma200;
  const half = SCORE_TREND_MAX / 2;
  const pricePts = capScore((priceDistance / TREND_FULL_DISTANCE) * half, half);
  const smaPts = capScore((smaDistance / TREND_FULL_DISTANCE) * half, half);
  return { score: pricePts + smaPts, priceDistance, smaDistance };
}

export function relativeStrengthScore(excess: number): number {
  return capScore((excess / RS_FULL_EXCESS) * SCORE_RS_MAX, SCORE_RS_MAX);
}

/**
 * Smooth pullback quality. Full score on [3%, 4%].
 * Raised-cosine decay to 0 at 2% and 6%. Outside the valid range: 0.
 */
export function pullbackQualityScore(distance: number): number {
  if (!isFiniteNumber(distance) || distance < PULLBACK_MIN || distance > PULLBACK_MAX) return 0;
  if (distance >= PULLBACK_IDEAL_LOW && distance <= PULLBACK_IDEAL_HIGH) return SCORE_PULLBACK_MAX;
  if (distance < PULLBACK_IDEAL_LOW) {
    const x = (PULLBACK_IDEAL_LOW - distance) / (PULLBACK_IDEAL_LOW - PULLBACK_MIN);
    return SCORE_PULLBACK_MAX * 0.5 * (1 + Math.cos(Math.PI * x));
  }
  const x = (distance - PULLBACK_IDEAL_HIGH) / (PULLBACK_MAX - PULLBACK_IDEAL_HIGH);
  return SCORE_PULLBACK_MAX * 0.5 * (1 + Math.cos(Math.PI * x));
}

export function triggerQualityScore(strengthAtr: number): number {
  return capScore((strengthAtr / TRIGGER_FULL_ATR) * SCORE_TRIGGER_MAX, SCORE_TRIGGER_MAX);
}

/** Lower ATR/Close is better. Equal values → full score (no division by zero). */
export function volatilityQualityScores(volRatios: readonly number[]): number[] {
  if (volRatios.length === 0) return [];
  let min = Infinity;
  let max = -Infinity;
  for (const v of volRatios) {
    if (!isFiniteNumber(v)) continue;
    if (v < min) min = v;
    if (v > max) max = v;
  }
  if (!Number.isFinite(min) || !Number.isFinite(max)) {
    return volRatios.map(() => 0);
  }
  const span = max - min;
  if (span < 1e-15) return volRatios.map(() => 15);
  return volRatios.map((v) => {
    if (!isFiniteNumber(v)) return 0;
    return ((max - v) / span) * 15;
  });
}

export function asOfIndex(bars: readonly DailyBar[], asOfDate: string | null): number {
  if (!asOfDate) return bars.length - 1;
  for (let i = bars.length - 1; i >= 0; i--) {
    if (bars[i]!.date <= asOfDate) return i;
  }
  return -1;
}

export function sliceThrough(bars: readonly DailyBar[], asOfDate: string | null): DailyBar[] {
  if (!asOfDate) return bars.slice();
  return bars.filter((b) => b.date <= asOfDate);
}

export { SMA_FAST, SMA_MID, SMA_SLOW, ATR_PERIOD, RETURN_HORIZON };
