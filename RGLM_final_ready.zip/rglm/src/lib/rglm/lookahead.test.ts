import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { calculateRGLMSignal } from "./engine.ts";
import { buildDemoMarket } from "../provider/demo-market.ts";
import type { DailyBar } from "./types.ts";

function run(spy: DailyBar[], symbols: ReturnType<typeof buildDemoMarket>["symbols"], asOf: string) {
  return calculateRGLMSignal({
    spyBars: spy,
    symbols,
    asOfDate: asOf,
    timestamp: `${asOf}T21:00:00.000Z`,
    dataSnapshotId: "LOOKAHEAD",
    dataStatus: "DEMO",
    universeMode: "DEMO_RESEARCH",
    coverageStatus: "COMPLETE",
    universeDiscovered: symbols.length,
    universeRejected: 0,
    spxFound: 1,
    spxExpected: 1,
    ndxFound: 1,
    ndxExpected: 1,
    cacheHits: symbols.length,
    providerRequests: 0,
    elapsedMs: 1,
  });
}

describe("look-ahead isolation", () => {
  it("future bar mutations do not change the as-of RGLM result", () => {
    const market = buildDemoMarket("2024-12-31");
    const asOf = market.spy[market.spy.length - 6]!.date;
    const baseline = run(market.spy, market.symbols, asOf);

    const blowUp = (bars: DailyBar[]): DailyBar[] =>
      bars.map((b) =>
        b.date > asOf
          ? { ...b, open: b.open * 4, high: b.high * 4, low: b.low * 4, close: b.close * 4 }
          : { ...b },
      );

    const mutated = run(
      blowUp(market.spy).concat({
        date: "2099-12-31",
        open: 1e6,
        high: 1e6,
        low: 1e6,
        close: 1e6,
        volume: 1,
      }),
      market.symbols.map((s) => ({ ...s, bars: blowUp(s.bars) })),
      asOf,
    );

    assert.equal(mutated.status, baseline.status);
    assert.equal(mutated.reasonCode, baseline.reasonCode);
    assert.equal(mutated.marketRegime, baseline.marketRegime);
    assert.equal(mutated.winner?.ticker, baseline.winner?.ticker);
    assert.equal(mutated.winner?.direction, baseline.winner?.direction);
    assert.equal(mutated.winner?.score, baseline.winner?.score);
    assert.equal(mutated.winner?.stop, baseline.winner?.stop);
    assert.equal(mutated.winner?.target3R, baseline.winner?.target3R);
    assert.equal(mutated.spy.regime, baseline.spy.regime);
    assert.equal(mutated.spy.volRatio, baseline.spy.volRatio);
  });
});
