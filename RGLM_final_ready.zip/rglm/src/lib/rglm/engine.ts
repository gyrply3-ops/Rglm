/**
 * RGLM v0.1 engine — one source of truth.
 *
 * The UI must never recompute these decisions. AI may only explain a stored result.
 */

import {
  ATR_PERIOD,
  MIN_HISTORY_BARS,
  MIN_PRODUCTION_ELIGIBLE,
  PRICE_BASIS,
  RESEARCH_RISK_BUDGET,
  RETURN_HORIZON,
  SCORE_QUALIFY,
  SMA_FAST,
  SMA_MID,
  SMA_SLOW,
  STRATEGY_VERSION,
} from "./constants.ts";
import {
  assetTrend,
  asOfIndex,
  calculateATR,
  calculateGlobalVolatility,
  calculateMarketRegime,
  calculatePullback,
  calculateReturn,
  calculateSMA,
  calculateTrigger,
  closesOf,
  pullbackQualityScore,
  recentHigh,
  recentLow,
  relativeStrengthScore,
  sliceThrough,
  trendQualityScore,
  triggerQualityScore,
  volatilityQualityScores,
} from "./indicators.ts";
import { validateRGLMData } from "./quality.ts";
import { calculateResearchLevels } from "./research.ts";
import type {
  CandidateMetrics,
  ChartPoint,
  Direction,
  EngineInput,
  EngineSymbol,
  GateResult,
  ReasonCode,
  RglmResult,
  ScoreBreakdown,
  SpyState,
} from "./types.ts";

export { PRICE_BASIS, STRATEGY_VERSION };

function spyStateFrom(bars: readonly import("./types.ts").DailyBar[], asOfDate: string | null): SpyState {
  const sliced = sliceThrough(bars, asOfDate);
  const i = sliced.length - 1;
  const empty: SpyState = {
    lastDate: sliced[i]?.date ?? "",
    close: sliced[i]?.close ?? NaN,
    sma20: null,
    sma50: null,
    sma200: null,
    atr20: null,
    return63: null,
    volRatio: null,
    volThreshold: null,
    regime: "UNAVAILABLE",
    volatilityState: "UNAVAILABLE",
    barCount: sliced.length,
    valid: false,
    failReason: "BENCHMARK_DATA_UNAVAILABLE",
  };
  if (i < 0) return empty;
  const quality = validateRGLMData(sliced, asOfDate ?? sliced[i]!.date, MIN_HISTORY_BARS);
  if (!quality.ok) {
    const stale = quality.issues.some((x) => x.code === "STALE_DATA");
    const hist = quality.issues.some((x) => x.code === "INSUFFICIENT_HISTORY");
    return {
      ...empty,
      lastDate: sliced[i]!.date,
      close: sliced[i]!.close,
      barCount: sliced.length,
      failReason: stale ? "STALE_DATA" : hist ? "INSUFFICIENT_HISTORY" : "DATA_QUALITY_FAILURE",
    };
  }
  const closes = closesOf(sliced);
  const sma20 = calculateSMA(closes, SMA_FAST, i);
  const sma50 = calculateSMA(closes, SMA_MID, i);
  const sma200 = calculateSMA(closes, SMA_SLOW, i);
  const atr20 = calculateATR(sliced, ATR_PERIOD, i);
  const return63 = calculateReturn(closes, RETURN_HORIZON, i);
  const vol = calculateGlobalVolatility(sliced, i);
  const regime = calculateMarketRegime(sliced[i]!.close, sma50, sma200);
  const ready =
    sma20 != null &&
    sma50 != null &&
    sma200 != null &&
    atr20 != null &&
    return63 != null &&
    vol.available &&
    regime !== "UNAVAILABLE";
  return {
    lastDate: sliced[i]!.date,
    close: sliced[i]!.close,
    sma20,
    sma50,
    sma200,
    atr20,
    return63,
    volRatio: vol.ratio,
    volThreshold: vol.threshold,
    regime,
    volatilityState: !vol.available ? "UNAVAILABLE" : vol.stress ? "VOLATILITY_STRESS" : "ACCEPTABLE",
    barCount: sliced.length,
    valid: ready,
    failReason: ready ? null : "BENCHMARK_DATA_UNAVAILABLE",
  };
}

function evaluateSymbol(
  symbol: EngineSymbol,
  spy: SpyState,
  spyBars: readonly import("./types.ts").DailyBar[],
  asOfDate: string | null,
): CandidateMetrics {
  const bars = sliceThrough(symbol.bars, asOfDate);
  const i = bars.length - 1;
  const lastDate = bars[i]?.date ?? "";
  const base = {
    ticker: symbol.ticker,
    company: symbol.company,
    exchange: symbol.exchange,
    close: bars[i]?.close ?? NaN,
    sma20: NaN,
    sma50: NaN,
    sma200: NaN,
    atr20: NaN,
    volRatio: NaN,
    return63: NaN,
    spyReturn63: spy.return63 ?? NaN,
    excess63: NaN,
    prevHigh: NaN,
    prevLow: NaN,
    pullback: {
      recentExtreme: NaN,
      distance: NaN,
      touched: false,
      closeVsSma20: NaN,
      valid: false,
    },
    triggerPassed: false,
    triggerStrengthAtr: 0,
    score: null,
    research: null,
    inSpx: symbol.inSpx,
    inNdx: symbol.inNdx,
    barCount: bars.length,
    lastDate,
  };

  const quality = validateRGLMData(bars, spy.lastDate || asOfDate, MIN_HISTORY_BARS);
  const dataGate: GateResult = {
    name: "dataQuality",
    passed: quality.ok,
    detail: quality.ok ? "OHLCV validation passed." : quality.issues.map((x) => x.message).join(" "),
  };
  const histGate: GateResult = {
    name: "minimumHistory",
    passed: bars.length >= MIN_HISTORY_BARS,
    detail: `${bars.length} sessions.`,
  };

  const regimeAllows = spy.regime === "TREND_UP" || spy.regime === "TREND_DOWN";
  const regimeGate: GateResult = {
    name: "marketRegime",
    passed: spy.valid && regimeAllows,
    detail: `SPY regime ${spy.regime}.`,
  };
  const volGate: GateResult = {
    name: "volatility",
    passed: spy.volatilityState === "ACCEPTABLE",
    detail: spy.volatilityState,
  };

  if (!quality.ok || i < 0) {
    return {
      ...base,
      direction: "LONG",
      gates: [
        dataGate,
        histGate,
        regimeGate,
        volGate,
        { name: "assetTrend", passed: false, detail: "Skipped." },
        { name: "relativeStrength", passed: false, detail: "Skipped." },
        { name: "pullback", passed: false, detail: "Skipped." },
        { name: "trigger", passed: false, detail: "Skipped." },
      ],
      passedHardGates: false,
    };
  }

  const closes = closesOf(bars);
  const sma20 = calculateSMA(closes, SMA_FAST, i);
  const sma50 = calculateSMA(closes, SMA_MID, i);
  const sma200 = calculateSMA(closes, SMA_SLOW, i);
  const atr20 = calculateATR(bars, ATR_PERIOD, i);
  const ret63 = calculateReturn(closes, RETURN_HORIZON, i);
  const direction = assetTrend(bars[i]!.close, sma50, sma200);
  const spyIdx = asOfIndex(spyBars, asOfDate ?? spy.lastDate);
  const spyCloses = closesOf(sliceThrough(spyBars, asOfDate ?? spy.lastDate));
  const spyRet = spy.return63 ?? calculateReturn(spyCloses, RETURN_HORIZON, spyIdx);

  const trendGate: GateResult = {
    name: "assetTrend",
    passed:
      direction != null &&
      ((spy.regime === "TREND_UP" && direction === "LONG") ||
        (spy.regime === "TREND_DOWN" && direction === "SHORT")),
    detail: direction ? `Asset trend ${direction}.` : "No aligned asset trend.",
  };

  const dir: Direction = direction ?? (spy.regime === "TREND_DOWN" ? "SHORT" : "LONG");
  const excess =
    ret63 != null && spyRet != null ? (dir === "LONG" ? ret63 - spyRet : spyRet - ret63) : null;
  const rsGate: GateResult = {
    name: "relativeStrength",
    passed: excess != null && excess > 0,
    detail:
      ret63 != null && spyRet != null
        ? `Asset 63D ${(ret63 * 100).toFixed(2)}% vs SPY ${(spyRet * 100).toFixed(2)}%.`
        : "63-day return unavailable.",
  };

  const pb = sma20 != null ? calculatePullback(bars, i, dir, sma20) : base.pullback;
  const pbGate: GateResult = {
    name: "pullback",
    passed: pb.valid,
    detail: Number.isFinite(pb.distance)
      ? `Pullback ${(pb.distance * 100).toFixed(2)}%; touch=${pb.touched}.`
      : "Pullback unavailable.",
  };

  const trig = calculateTrigger(bars, i, dir);
  const trigGate: GateResult = {
    name: "trigger",
    passed: trig.passed,
    detail: trig.passed ? `Breakout ${trig.strengthAtr.toFixed(3)} ATR.` : "Entry trigger not met.",
  };

  const histOk = bars.length >= MIN_HISTORY_BARS && sma200 != null && atr20 != null && ret63 != null;
  histGate.passed = histOk;
  histGate.detail = `${bars.length} sessions; SMA200=${sma200 != null}; ATR=${atr20 != null}.`;

  const gates = [dataGate, histGate, regimeGate, volGate, trendGate, rsGate, pbGate, trigGate];
  const passedHardGates = gates.every((g) => g.passed);

  return {
    ...base,
    direction: dir,
    close: bars[i]!.close,
    sma20: sma20 ?? NaN,
    sma50: sma50 ?? NaN,
    sma200: sma200 ?? NaN,
    atr20: atr20 ?? NaN,
    volRatio: atr20 != null && bars[i]!.close ? atr20 / bars[i]!.close : NaN,
    return63: ret63 ?? NaN,
    spyReturn63: spyRet ?? NaN,
    excess63: excess ?? NaN,
    prevHigh: trig.prevHigh ?? NaN,
    prevLow: trig.prevLow ?? NaN,
    pullback: pb,
    triggerPassed: trig.passed,
    triggerStrengthAtr: trig.strengthAtr,
    gates,
    passedHardGates,
    research: passedHardGates ? calculateResearchLevels(bars, i, dir) : null,
  };
}

function compareCandidates(a: CandidateMetrics, b: CandidateMetrics): number {
  const as = a.score?.total ?? -1;
  const bs = b.score?.total ?? -1;
  if (bs !== as) return bs - as;
  const ars = a.score?.relativeStrength ?? -1;
  const brs = b.score?.relativeStrength ?? -1;
  if (brs !== ars) return brs - ars;
  const at = a.score?.trend ?? -1;
  const bt = b.score?.trend ?? -1;
  if (bt !== at) return bt - at;
  const ap = a.score?.pullback ?? -1;
  const bp = b.score?.pullback ?? -1;
  if (bp !== ap) return bp - ap;
  const av = a.volRatio;
  const bv = b.volRatio;
  if (av !== bv) return av - bv;
  return a.ticker.localeCompare(b.ticker);
}

function buildChart(symbol: EngineSymbol, asOfDate: string | null): ChartPoint[] {
  const bars = sliceThrough(symbol.bars, asOfDate);
  const closes = closesOf(bars);
  const start = Math.max(0, bars.length - 180);
  const points: ChartPoint[] = [];
  for (let i = start; i < bars.length; i++) {
    points.push({
      date: bars[i]!.date,
      close: bars[i]!.close,
      sma20: calculateSMA(closes, SMA_FAST, i),
      sma50: calculateSMA(closes, SMA_MID, i),
      sma200: calculateSMA(closes, SMA_SLOW, i),
      high20: recentHigh(bars, i),
      low20: recentLow(bars, i),
    });
  }
  return points;
}

function reasonText(code: ReasonCode): string {
  switch (code) {
    case "TRADE_SIGNAL":
      return "A single RGLM-qualified candidate passed every hard gate and scored at or above 70.";
    case "TRANSITION_MARKET":
      return "Market regime is TRANSITION, therefore RGLM is inactive.";
    case "VOLATILITY_STRESS":
      return "SPY volatility ratio exceeds the 90th percentile of the previous 252 sessions.";
    case "BENCHMARK_DATA_UNAVAILABLE":
      return "SPY benchmark data failed validation.";
    case "DATA_QUALITY_FAILURE":
      return "Required market data failed quality checks.";
    case "INSUFFICIENT_HISTORY":
      return "Insufficient completed daily sessions for RGLM.";
    case "INSUFFICIENT_MARKET_COVERAGE":
      return "Eligible U.S. common-stock universe is below the 3,000-name production minimum.";
    case "INDEX_DATA_UNAVAILABLE":
      return "S&P 500 or Nasdaq-100 membership could not be verified.";
    case "NO_HARD_GATE_SURVIVORS":
      return "No candidate passed every hard gate.";
    case "NO_QUALIFIED_CANDIDATES":
      return "Hard-gate survivors existed but none reached RGLM score 70.";
    case "DATA_LIMITATION":
      return "Provider limits prevent a complete validated scan. No trade.";
    case "DATA_ERROR":
      return "The data provider returned an error. No trade.";
    case "RATE_LIMITED":
      return "The data provider rate-limited the request. No trade.";
    case "API_NOT_CONFIGURED":
      return "EODHD API token is not configured. No live scan.";
    case "STALE_DATA":
      return "Latest completed session is stale relative to the expected date.";
    case "INVALID_RESEARCH_STOP":
      return "Qualified candidates existed but none produced a valid research stop.";
    default:
      return "No trade.";
  }
}

export function calculateRGLMSignal(input: EngineInput): RglmResult {
  const spy = spyStateFrom(input.spyBars, input.asOfDate);
  const statsBase = {
    universeDiscovered: input.universeDiscovered,
    universeEligible: input.symbols.length,
    universeRejected: input.universeRejected,
    dataQualityRejects: 0,
    insufficientHistoryRejects: 0,
    hardGateSurvivors: 0,
    scoreQualified: 0,
    finalCandidate: null as string | null,
    spxFound: input.spxFound,
    spxExpected: input.spxExpected,
    ndxFound: input.ndxFound,
    ndxExpected: input.ndxExpected,
    expandedUniverse: input.symbols.length,
    uniqueEligible: input.symbols.length,
    cacheHits: input.cacheHits,
    providerRequests: input.providerRequests,
    elapsedMs: input.elapsedMs,
  };

  const noTrade = (code: ReasonCode, extras: Partial<RglmResult> = {}): RglmResult => ({
    strategyVersion: STRATEGY_VERSION,
    status: "NO_TRADE",
    reasonCode: code,
    reasonText: reasonText(code),
    timestamp: input.timestamp,
    dataSnapshotId: input.dataSnapshotId,
    marketRegime: spy.regime,
    volatilityStress: spy.volatilityState === "VOLATILITY_STRESS",
    volatilityState: spy.volatilityState,
    spyVolRatio: spy.volRatio,
    spyVolThreshold: spy.volThreshold,
    universeCount: input.universeDiscovered,
    eligibleCount: input.symbols.length,
    hardGateSurvivors: 0,
    qualifiedCount: 0,
    coverageStatus: input.coverageStatus,
    dataStatus: input.dataStatus,
    universeMode: input.universeMode,
    universeKind: "CURRENT_CONSTITUENT_UNIVERSE",
    provider: "EODHD",
    latestCompletedSession: spy.lastDate || input.asOfDate,
    winner: null,
    scoreBreakdown: null,
    reasons: [reasonText(code), input.coverageReason].filter(Boolean) as string[],
    scanStatistics: statsBase,
    spy,
    checklist: [
      {
        name: "marketRegime",
        passed: spy.regime === "TREND_UP" || spy.regime === "TREND_DOWN",
        detail: String(spy.regime),
      },
      {
        name: "volatility",
        passed: spy.volatilityState === "ACCEPTABLE",
        detail: spy.volatilityState,
      },
      {
        name: "dataQuality",
        passed: spy.valid,
        detail: spy.failReason ?? "SPY valid",
      },
    ],
    rankedQualified: [],
    rejectedHighScores: [],
    chart: [],
    researchDisclaimer:
      "Research / paper only. Not an order, fill, or recommendation. RGLM Score is not a probability of profit.",
    ...extras,
  });

  if (
    input.universeMode === "PRODUCTION" &&
    (input.coverageStatus === "INSUFFICIENT" ||
      input.coverageStatus === "PARTIAL" ||
      input.coverageStatus === "UNKNOWN")
  ) {
    const code: ReasonCode =
      input.coverageStatus === "INSUFFICIENT" ? "INSUFFICIENT_MARKET_COVERAGE" : "DATA_LIMITATION";
    return noTrade(code);
  }

  if (input.universeMode === "PRODUCTION" && input.symbols.length < MIN_PRODUCTION_ELIGIBLE) {
    return noTrade("INSUFFICIENT_MARKET_COVERAGE");
  }

  if (!spy.valid) {
    const code = (spy.failReason as ReasonCode) || "BENCHMARK_DATA_UNAVAILABLE";
    return noTrade(code);
  }
  if (spy.regime === "TRANSITION") return noTrade("TRANSITION_MARKET");
  if (spy.volatilityState === "VOLATILITY_STRESS") return noTrade("VOLATILITY_STRESS");

  const evaluated = input.symbols.map((s) => evaluateSymbol(s, spy, input.spyBars, input.asOfDate));
  statsBase.dataQualityRejects = evaluated.filter((c) => !c.gates.find((g) => g.name === "dataQuality")?.passed).length;
  statsBase.insufficientHistoryRejects = evaluated.filter(
    (c) => !c.gates.find((g) => g.name === "minimumHistory")?.passed,
  ).length;

  const survivors = evaluated.filter((c) => c.passedHardGates && c.research);
  statsBase.hardGateSurvivors = survivors.length;

  if (survivors.length === 0) {
    const rejectedHighScores = evaluated
      .filter((c) => !c.passedHardGates)
      .slice()
      .sort((a, b) => (b.excess63 || 0) - (a.excess63 || 0))
      .slice(0, 8)
      .map((c) => ({
        ticker: c.ticker,
        company: c.company,
        direction: c.direction,
        failedGates: c.gates.filter((g) => !g.passed).map((g) => g.name),
        detail: c.gates
          .filter((g) => !g.passed)
          .map((g) => `${g.name}: ${g.detail}`)
          .join(" "),
      }));
    return noTrade("NO_HARD_GATE_SURVIVORS", {
      hardGateSurvivors: 0,
      rejectedHighScores,
      scanStatistics: { ...statsBase, hardGateSurvivors: 0 },
    });
  }

  const volScores = volatilityQualityScores(survivors.map((s) => s.volRatio));
  for (let i = 0; i < survivors.length; i++) {
    const c = survivors[i]!;
    const t = trendQualityScore(c.close, c.sma50, c.sma200, c.direction);
    const rs = relativeStrengthScore(c.excess63);
    const pb = pullbackQualityScore(c.pullback.distance);
    const vol = volScores[i] ?? 0;
    const trig = triggerQualityScore(c.triggerStrengthAtr);
    const breakdown: ScoreBreakdown = {
      trend: t.score,
      relativeStrength: rs,
      pullback: pb,
      volatility: vol,
      trigger: trig,
      total: t.score + rs + pb + vol + trig,
      trendPriceDistance: t.priceDistance,
      trendSmaDistance: t.smaDistance,
      rsExcess: c.excess63,
      pullbackDistance: c.pullback.distance,
      volRatio: c.volRatio,
      triggerStrengthAtr: c.triggerStrengthAtr,
    };
    c.score = breakdown;
  }

  const qualified = survivors.filter((c) => (c.score?.total ?? 0) >= SCORE_QUALIFY).sort(compareCandidates);
  statsBase.scoreQualified = qualified.length;

  if (qualified.length === 0) {
    return noTrade("NO_QUALIFIED_CANDIDATES", {
      hardGateSurvivors: survivors.length,
      qualifiedCount: 0,
      scanStatistics: { ...statsBase },
      rejectedHighScores: survivors
        .slice()
        .sort(compareCandidates)
        .slice(0, 8)
        .map((c) => ({
          ticker: c.ticker,
          company: c.company,
          direction: c.direction,
          failedGates: ["scoreThreshold"],
          detail: `Score ${c.score?.total.toFixed(2) ?? "n/a"} < 70.`,
        })),
    });
  }

  const winnerCand = qualified[0]!;
  if (!winnerCand.research || !winnerCand.score) {
    return noTrade("INVALID_RESEARCH_STOP");
  }

  statsBase.finalCandidate = winnerCand.ticker;
  const winnerSymbol = input.symbols.find((s) => s.ticker === winnerCand.ticker)!;

  return {
    strategyVersion: STRATEGY_VERSION,
    status: "TRADE",
    reasonCode: "TRADE_SIGNAL",
    reasonText: reasonText("TRADE_SIGNAL"),
    timestamp: input.timestamp,
    dataSnapshotId: input.dataSnapshotId,
    marketRegime: spy.regime,
    volatilityStress: false,
    volatilityState: spy.volatilityState,
    spyVolRatio: spy.volRatio,
    spyVolThreshold: spy.volThreshold,
    universeCount: input.universeDiscovered,
    eligibleCount: input.symbols.length,
    hardGateSurvivors: survivors.length,
    qualifiedCount: qualified.length,
    coverageStatus: input.coverageStatus,
    dataStatus: input.dataStatus,
    universeMode: input.universeMode,
    universeKind: "CURRENT_CONSTITUENT_UNIVERSE",
    provider: "EODHD",
    latestCompletedSession: spy.lastDate,
    winner: {
      ticker: winnerCand.ticker,
      company: winnerCand.company,
      direction: winnerCand.direction,
      score: winnerCand.score.total,
      currentPrice: winnerCand.close,
      referenceEntry: winnerCand.research.referenceEntry,
      stop: winnerCand.research.stop,
      target3R: winnerCand.research.target3R,
      theoreticalRiskBudget: RESEARCH_RISK_BUDGET,
      theoreticalPositionSize: winnerCand.research.theoreticalAllocation,
      theoreticalQuantity: winnerCand.research.theoreticalQuantity,
      allocationCapped: winnerCand.research.allocationCapped,
      relativeStrength: winnerCand.score.relativeStrength,
      excess63: winnerCand.excess63,
      return63: winnerCand.return63,
      spyReturn63: winnerCand.spyReturn63,
      inSpx: winnerCand.inSpx,
      inNdx: winnerCand.inNdx,
    },
    scoreBreakdown: winnerCand.score,
    reasons: [`${winnerCand.ticker} passed all hard gates with score ${winnerCand.score.total.toFixed(2)}.`],
    scanStatistics: statsBase,
    spy,
    checklist: winnerCand.gates,
    rankedQualified: qualified.slice(0, 12).map((c) => ({
      ticker: c.ticker,
      company: c.company,
      direction: c.direction,
      score: c.score!.total,
      breakdown: c.score!,
    })),
    rejectedHighScores: evaluated
      .filter((c) => c.ticker !== winnerCand.ticker)
      .filter((c) => !c.passedHardGates || (c.score?.total ?? 0) < SCORE_QUALIFY)
      .slice(0, 8)
      .map((c) => ({
        ticker: c.ticker,
        company: c.company,
        direction: c.direction,
        failedGates: c.passedHardGates
          ? ["scoreThreshold"]
          : c.gates.filter((g) => !g.passed).map((g) => g.name),
        detail: c.passedHardGates
          ? `Score ${c.score?.total.toFixed(2) ?? "n/a"} < 70.`
          : c.gates
              .filter((g) => !g.passed)
              .map((g) => g.name)
              .join(", "),
      })),
    chart: buildChart(winnerSymbol, input.asOfDate),
    researchDisclaimer:
      "Research / paper only. Reference entry is the latest completed daily close — not a fill. Research target is 3R and is not guaranteed.",
  };
}

export function rankCandidates(cands: CandidateMetrics[]): CandidateMetrics[] {
  return cands.slice().sort(compareCandidates);
}
