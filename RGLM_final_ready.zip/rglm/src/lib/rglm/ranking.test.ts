import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { rankCandidates } from "./engine.ts";
import type { CandidateMetrics, ScoreBreakdown } from "./types.ts";

function cand(
  ticker: string,
  score: Partial<ScoreBreakdown> & { total: number },
  volRatio = 0.02,
): CandidateMetrics {
  const breakdown: ScoreBreakdown = {
    trend: 0,
    relativeStrength: 0,
    pullback: 0,
    volatility: 0,
    trigger: 0,
    trendPriceDistance: 0,
    trendSmaDistance: 0,
    rsExcess: 0,
    pullbackDistance: 0,
    volRatio,
    triggerStrengthAtr: 0,
    ...score,
  };
  return {
    ticker,
    company: ticker,
    exchange: "US",
    direction: "LONG",
    close: 10,
    sma20: 9,
    sma50: 8,
    sma200: 7,
    atr20: 0.2,
    volRatio,
    return63: 0.1,
    spyReturn63: 0.05,
    excess63: 0.05,
    prevHigh: 9.9,
    prevLow: 9.5,
    pullback: { recentExtreme: 10.4, distance: 0.035, touched: true, closeVsSma20: 1, valid: true },
    triggerPassed: true,
    triggerStrengthAtr: 0.2,
    gates: [],
    passedHardGates: true,
    score: breakdown,
    research: null,
    inSpx: false,
    inNdx: false,
    barCount: 320,
    lastDate: "2024-12-31",
  };
}

describe("ranking tie-breakers", () => {
  it("orders by total score, then RS, trend, pullback, then lower vol", () => {
    const ranked = rankCandidates([
      cand("A", { total: 80, relativeStrength: 10, trend: 10, pullback: 10 }, 0.03),
      cand("B", { total: 80, relativeStrength: 12, trend: 10, pullback: 10 }, 0.03),
      cand("C", { total: 90, relativeStrength: 1, trend: 1, pullback: 1 }, 0.09),
      cand("D", { total: 80, relativeStrength: 10, trend: 12, pullback: 10 }, 0.03),
      cand("E", { total: 80, relativeStrength: 10, trend: 10, pullback: 12 }, 0.03),
      cand("F", { total: 80, relativeStrength: 10, trend: 10, pullback: 10 }, 0.01),
    ]);
    assert.deepEqual(
      ranked.map((c) => c.ticker),
      ["C", "B", "D", "E", "F", "A"],
    );
  });
});
