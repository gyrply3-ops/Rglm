import assert from "node:assert/strict";
import { test } from "node:test";
import { lastCompletedWeekday } from "./bars.ts";

test("lastCompletedWeekday uses 16:00 America/New_York rather than a fixed UTC hour", () => {
  // 15:59 ET on a DST date: today's session is not complete.
  const beforeClose = new Date("2026-07-15T19:59:00Z");
  assert.equal(lastCompletedWeekday(beforeClose), "2026-07-14");

  // 16:00 ET: today's session is complete.
  const afterClose = new Date("2026-07-15T20:00:00Z");
  assert.equal(lastCompletedWeekday(afterClose), "2026-07-15");

  // Saturday rolls back to Friday.
  const saturday = new Date("2026-07-18T20:00:00Z");
  assert.equal(lastCompletedWeekday(saturday), "2026-07-17");
});
