/**
 * RGLM v0.1 — frozen strategy parameters.
 *
 * Any rule or threshold change MUST bump the version to RGLM-v0.2.
 * Do not silently retune these values to produce more signals.
 */

export const STRATEGY_VERSION = "RGLM-v0.1" as const;
export const STRATEGY_LABEL = "RGLM v0.1";
export const TIMEFRAME = "DAILY" as const;

/** Price basis: split-adjusted OHLC reconstructed from EODHD adjusted_close. */
export const PRICE_BASIS =
  "SPLIT_ADJUSTED_OHLC — unadjusted OHLC scaled by adjusted_close/close so SMA, ATR, highs/lows and returns share one series.";

export const SMA_FAST = 20;
export const SMA_MID = 50;
export const SMA_SLOW = 200;
export const ATR_PERIOD = 20;
export const RETURN_HORIZON = 63;
export const VOL_LOOKBACK = 252;
export const VOL_PERCENTILE = 90;
export const MIN_HISTORY_BARS = 252;
export const PREFERRED_HISTORY_BARS = 300;
/** Bars required so ATR exists for the previous 252 sessions plus SMA200. */
export const ENGINE_HISTORY_BARS = 320;

export const PULLBACK_LOOKBACK = 20;
export const PULLBACK_TOUCH_LOOKBACK = 10;
export const PULLBACK_MIN = 0.02;
export const PULLBACK_MAX = 0.06;
export const PULLBACK_IDEAL_LOW = 0.03;
export const PULLBACK_IDEAL_HIGH = 0.04;

export const TREND_FULL_DISTANCE = 0.1;
export const RS_FULL_EXCESS = 0.1;
export const TRIGGER_FULL_ATR = 1.0;

export const SCORE_TREND_MAX = 25;
export const SCORE_RS_MAX = 25;
export const SCORE_PULLBACK_MAX = 20;
export const SCORE_VOL_MAX = 15;
export const SCORE_TRIGGER_MAX = 15;
export const SCORE_TOTAL_MAX = 100;
export const SCORE_QUALIFY = 70;

export const ATR_STOP_MULT = 1.5;
export const SWING_LOOKBACK = 10;
export const TARGET_R_MULT = 3;

export const RESEARCH_CAPITAL = 10_000;
export const RESEARCH_RISK_PCT = 0.005;
export const RESEARCH_RISK_BUDGET = RESEARCH_CAPITAL * RESEARCH_RISK_PCT;
export const MAX_ALLOCATION_PCT = 0.2;

export const MIN_PRODUCTION_ELIGIBLE = 3000;
export const STALE_CALENDAR_DAYS = 7;
export const SUSPICIOUS_GAP_CALENDAR_DAYS = 14;
export const IMPOSSIBLE_ABS_LOG_RETURN = 1.0;

export const PROVIDER_NAME = "EODHD";
export const BENCHMARK_TICKER = "SPY";
export const BENCHMARK_EXCHANGE = "US";
export const SPX_INDEX = "GSPC.INDX";
export const NDX_INDEX = "NDX.INDX";

export const SCAN_PHASES = [
  "CONNECTING_TO_DATA_PROVIDER",
  "LOADING_UNIVERSE",
  "VALIDATING_UNIVERSE",
  "LOADING_MARKET_DATA",
  "VALIDATING_DATA",
  "CALCULATING_INDICATORS",
  "APPLYING_HARD_GATES",
  "SCORING_CANDIDATES",
  "RANKING_CANDIDATES",
] as const;
