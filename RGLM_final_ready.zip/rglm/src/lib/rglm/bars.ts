import type { DailyBar } from "./types.ts";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function isoDateUTC(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function parseIsoDate(date: string): Date {
  return new Date(`${date}T00:00:00Z`);
}

/**
 * Conservative completed US cash-session date. The NYSE/Nasdaq regular session
 * closes at 16:00 America/New_York; using the IANA zone avoids a fixed-UTC
 * assumption during US daylight-saving transitions. Market holidays are handled
 * by the provider response: if the requested date has no bar, the latest returned
 * completed session is used.
 */
export function lastCompletedWeekday(now = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(now);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  const y = Number(get("year"));
  const m = Number(get("month"));
  const day = Number(get("day"));
  const hour = Number(get("hour"));
  const minute = Number(get("minute"));
  const local = new Date(Date.UTC(y, m - 1, day));

  // Before 16:00 ET, today's regular session is not complete.
  if (hour < 16 || (hour === 16 && minute < 0)) local.setUTCDate(local.getUTCDate() - 1);

  while (local.getUTCDay() === 0 || local.getUTCDay() === 6) local.setUTCDate(local.getUTCDate() - 1);
  return isoDateUTC(local);
}

export function weekdaySessionsEnding(endDate: string, count: number): string[] {
  const dates: string[] = [];
  const d = parseIsoDate(endDate);
  while (dates.length < count) {
    const dow = d.getUTCDay();
    if (dow !== 0 && dow !== 6) dates.push(isoDateUTC(d));
    d.setUTCDate(d.getUTCDate() - 1);
  }
  return dates.reverse();
}

export function mulberry32(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function makeBar(date: string, close: number, range = 0.008, volume = 1_000_000): DailyBar {
  const high = close * (1 + range);
  const low = close * (1 - range);
  const open = close;
  return { date, open, high, low, close, volume };
}

export function geometricWalk(
  dates: readonly string[],
  start: number,
  drift: number,
  vol: number,
  rng: () => number,
): DailyBar[] {
  const bars: DailyBar[] = [];
  let px = start;
  for (const date of dates) {
    const shock = (rng() - 0.48) * 2 * vol;
    px = Math.max(1, px * (1 + drift + shock));
    const range = Math.max(0.004, Math.abs(shock) + 0.004);
    const close = px;
    const open = px / (1 + shock * 0.25);
    const high = Math.max(open, close) * (1 + range * 0.45);
    const low = Math.min(open, close) * (1 - range * 0.45);
    bars.push({
      date,
      open,
      high,
      low,
      close,
      volume: 800_000 + Math.floor(rng() * 1_200_000),
    });
  }
  return bars;
}

/**
 * Overwrite the last 21 sessions so a LONG pullback + trigger is structurally valid
 * without violating OHLC or creating an impossible return versus the prior bar.
 */
export function applyLongPullbackTrigger(bars: DailyBar[]): DailyBar[] {
  const out = bars.map((b) => ({ ...b }));
  const i = out.length - 1;
  if (i < 25) return out;
  const base = out[i - 21]!.close;
  const H = base * 1.045;
  const entry = H * 0.965;

  for (let k = i - 20; k <= i; k++) {
    const isPeak = k === i - 8;
    const isLast = k === i;
    const isPrev = k === i - 1;
    let close: number;
    let high: number;
    let low: number;
    let open: number;
    if (isLast) {
      close = entry;
      open = entry * 0.998;
      high = entry * 1.003;
      low = entry * 0.994;
    } else if (isPrev) {
      close = entry * 0.992;
      open = close;
      high = entry * 0.997;
      low = close * 0.992;
    } else if (isPeak) {
      close = entry * 0.99;
      open = close;
      high = H;
      low = close * 0.99;
    } else {
      close = entry * 0.986;
      open = close;
      high = Math.min(H * 0.998, close * 1.012);
      low = close * 0.99;
    }
    high = Math.max(high, open, close);
    low = Math.min(low, open, close);
    out[k] = { ...out[k]!, open, high, low, close, volume: 1_750_000 };
  }
  return out;
}

export function applyShortPullbackTrigger(bars: DailyBar[]): DailyBar[] {
  const out = bars.map((b) => ({ ...b }));
  const i = out.length - 1;
  if (i < 25) return out;
  const base = out[i - 21]!.close;
  const L = base * 0.955;
  const entry = L * 1.035;

  for (let k = i - 20; k <= i; k++) {
    const isTrough = k === i - 8;
    const isLast = k === i;
    const isPrev = k === i - 1;
    let close: number;
    let high: number;
    let low: number;
    let open: number;
    if (isLast) {
      close = entry;
      open = entry * 1.002;
      high = entry * 1.006;
      low = entry * 0.997;
    } else if (isPrev) {
      close = entry * 1.008;
      open = close;
      high = close * 1.008;
      low = entry * 1.003;
    } else if (isTrough) {
      close = entry * 1.01;
      open = close;
      high = close * 1.01;
      low = L;
    } else {
      close = entry * 1.014;
      open = close;
      high = close * 1.01;
      low = Math.max(L * 1.002, close * 0.988);
    }
    high = Math.max(high, open, close);
    low = Math.min(low, open, close);
    out[k] = { ...out[k]!, open, high, low, close, volume: 1_750_000 };
  }
  return out;
}

/**
 * Reconstruct split-adjusted OHLC from EODHD raw OHLC + adjusted_close.
 * Factor = adjusted_close / close. All strategy math uses this series.
 */
export function normalizeEodBar(raw: {
  date?: unknown;
  open?: unknown;
  high?: unknown;
  low?: unknown;
  close?: unknown;
  adjusted_close?: unknown;
  adjustedClose?: unknown;
  volume?: unknown;
}): DailyBar | null {
  if (typeof raw.date !== "string" || !DATE_RE.test(raw.date)) return null;
  const close = Number(raw.close);
  const adj = Number(raw.adjusted_close ?? raw.adjustedClose ?? raw.close);
  const open = Number(raw.open);
  const high = Number(raw.high);
  const low = Number(raw.low);
  const volume = Number(raw.volume);
  if (![close, adj, open, high, low].every((v) => Number.isFinite(v) && v > 0)) return null;
  if (!Number.isFinite(volume) || volume < 0) return null;
  const factor = close === 0 ? 1 : adj / close;
  if (!Number.isFinite(factor) || factor <= 0) return null;
  const aOpen = open * factor;
  const aHigh = high * factor;
  const aLow = low * factor;
  const aClose = adj;
  const hi = Math.max(aHigh, aOpen, aClose);
  const lo = Math.min(aLow, aOpen, aClose);
  return { date: raw.date, open: aOpen, high: hi, low: lo, close: aClose, volume };
}

export function mergeBarRange(existing: DailyBar[], incoming: DailyBar[]): DailyBar[] {
  const map = new Map<string, DailyBar>();
  for (const b of existing) map.set(b.date, b);
  for (const b of incoming) map.set(b.date, b);
  return [...map.values()].sort((a, b) => a.date.localeCompare(b.date));
}
