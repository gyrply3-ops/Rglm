import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  applyLongPullbackTrigger,
  geometricWalk,
  makeBar,
  mulberry32,
  weekdaySessionsEnding,
} from "./bars.ts";
import { calculateResearchLevels } from "./research.ts";
import { calculateRGLMSignal } from "./engine.ts";
import { SCORE_QUALIFY, STRATEGY_VERSION } from "./constants.ts";
import { buildDemoMarket } from "../provider/demo-market.ts";
import type { DailyBar, EngineSymbol } from "./types.ts";

function uptrendSpy(): DailyBar[] {
  const dates = weekdaySessionsEnding("2024-12-31", 320);
  return geometricWalk(dates, 400, 0.0005, 0.005, mulberry32(1));
}

function plantedLong(ticker: string, spy: DailyBar[]): EngineSymbol {
  const dates = spy.map((b) => b.date);
  const bars = applyLongPullbackTrigger(geometricWalk(dates, 80, 0.0009, 0.007, mulberry32(42)));
  return { ticker, company: ticker, exchange: "US", bars, inSpx: true, inNdx: false };
}

describe("research stop/target/size", () => {
  it("long stop is min(ATR stop, swing low) and target is 3R", () => {
    const dates = weekdaySessionsEnding("2024-12-31", 40);
    const bars = dates.map((d) => makeBar(d, 100, 0.01));
    const i = bars.length - 1;
    const levels = calculateResearchLevels(bars, i, "LONG");
    assert.ok(levels);
    assert.equal(levels.referenceEntry, bars[i]!.close);
    assert.ok(levels.stop < levels.referenceEntry);
    const r = levels.referenceEntry - levels.stop;
    assert.ok(Math.abs(levels.target3R - (levels.referenceEntry + 3 * r)) < 1e-9);
    assert.equal(levels.theoreticalRiskBudget, 50);
    assert.ok(levels.theoreticalQuantity > 0);
    assert.ok(levels.theoreticalAllocation <= 2000 + 1e-9);
  });

  it("short stop is max(ATR stop, swing high)", () => {
    const dates = weekdaySessionsEnding("2024-12-31", 40);
    const bars = dates.map((d) => makeBar(d, 100, 0.01));
    const i = bars.length - 1;
    const levels = calculateResearchLevels(bars, i, "SHORT");
    assert.ok(levels);
    assert.ok(levels.stop > levels.referenceEntry);
  });
});

describe("engine decisions", () => {
  it("returns NO TRADE in TRANSITION", () => {
    const dates = weekdaySessionsEnding("2024-12-31", 320);
    const spy = dates.map((d, i) => makeBar(d, 100 + Math.sin(i / 8) * 2, 0.004));
    const result = calculateRGLMSignal({
      spyBars: spy,
      symbols: [plantedLong("AAA", spy)],
      asOfDate: "2024-12-31",
      timestamp: "2024-12-31T21:00:00.000Z",
      dataSnapshotId: "TEST",
      dataStatus: "DEMO",
      universeMode: "DEMO_RESEARCH",
      coverageStatus: "COMPLETE",
      universeDiscovered: 1,
      universeRejected: 0,
      spxFound: 0,
      spxExpected: 0,
      ndxFound: 0,
      ndxExpected: 0,
      cacheHits: 1,
      providerRequests: 0,
      elapsedMs: 1,
    });
    assert.equal(result.status, "NO_TRADE");
    assert.ok(["TRANSITION_MARKET", "BENCHMARK_DATA_UNAVAILABLE"].includes(result.reasonCode));
  });

  it("returns NO TRADE when SPY is missing", () => {
    const result = calculateRGLMSignal({
      spyBars: [],
      symbols: [],
      asOfDate: "2024-12-31",
      timestamp: "2024-12-31T21:00:00.000Z",
      dataSnapshotId: "TEST",
      dataStatus: "DEMO",
      universeMode: "DEMO_RESEARCH",
      coverageStatus: "COMPLETE",
      universeDiscovered: 0,
      universeRejected: 0,
      spxFound: 0,
      spxExpected: 500,
      ndxFound: 0,
      ndxExpected: 100,
      cacheHits: 0,
      providerRequests: 0,
      elapsedMs: 1,
    });
    assert.equal(result.status, "NO_TRADE");
    assert.equal(result.reasonCode, "BENCHMARK_DATA_UNAVAILABLE");
  });

  it("enforces production 3000-name minimum", () => {
    const spy = uptrendSpy();
    const result = calculateRGLMSignal({
      spyBars: spy,
      symbols: [plantedLong("AAA", spy)],
      asOfDate: "2024-12-31",
      timestamp: "2024-12-31T21:00:00.000Z",
      dataSnapshotId: "TEST",
      dataStatus: "LIVE",
      universeMode: "PRODUCTION",
      coverageStatus: "COMPLETE",
      universeDiscovered: 1,
      universeRejected: 0,
      spxFound: 1,
      spxExpected: 500,
      ndxFound: 0,
      ndxExpected: 100,
      cacheHits: 1,
      providerRequests: 0,
      elapsedMs: 1,
    });
    assert.equal(result.status, "NO_TRADE");
    assert.equal(result.reasonCode, "INSUFFICIENT_MARKET_COVERAGE");
  });

  it("demo market is deterministic and tagged DEMO", () => {
    const m1 = buildDemoMarket("2024-12-31");
    const m2 = buildDemoMarket("2024-12-31");
    const a = calculateRGLMSignal({
      spyBars: m1.spy,
      symbols: m1.symbols,
      asOfDate: m1.asOfDate,
      timestamp: "2024-12-31T21:00:00.000Z",
      dataSnapshotId: "RGLM_SCAN_DEMO_A",
      dataStatus: "DEMO",
      universeMode: "DEMO_RESEARCH",
      coverageStatus: "COMPLETE",
      universeDiscovered: m1.discovered,
      universeRejected: m1.rejected,
      spxFound: m1.spxTickers.size,
      spxExpected: m1.spxTickers.size,
      ndxFound: m1.ndxTickers.size,
      ndxExpected: m1.ndxTickers.size,
      cacheHits: m1.symbols.length,
      providerRequests: 0,
      elapsedMs: 2,
    });
    const b = calculateRGLMSignal({
      spyBars: m2.spy,
      symbols: m2.symbols,
      asOfDate: m2.asOfDate,
      timestamp: "2024-12-31T21:00:00.000Z",
      dataSnapshotId: "RGLM_SCAN_DEMO_A",
      dataStatus: "DEMO",
      universeMode: "DEMO_RESEARCH",
      coverageStatus: "COMPLETE",
      universeDiscovered: m2.discovered,
      universeRejected: m2.rejected,
      spxFound: m2.spxTickers.size,
      spxExpected: m2.spxTickers.size,
      ndxFound: m2.ndxTickers.size,
      ndxExpected: m2.ndxTickers.size,
      cacheHits: m2.symbols.length,
      providerRequests: 0,
      elapsedMs: 2,
    });
    assert.equal(a.strategyVersion, STRATEGY_VERSION);
    assert.equal(a.dataStatus, "DEMO");
    assert.equal(a.status, b.status);
    assert.equal(a.reasonCode, b.reasonCode);
    assert.equal(a.winner?.ticker, b.winner?.ticker);
    assert.equal(a.winner?.score, b.winner?.score);
    assert.equal(a.winner?.stop, b.winner?.stop);
    assert.equal(a.winner?.target3R, b.winner?.target3R);
    if (a.status === "TRADE") {
      assert.ok((a.winner?.score ?? 0) >= SCORE_QUALIFY);
      assert.equal(a.rankedQualified.length >= 1, true);
    }
  });

  it("70 threshold rejects a 69.99 survivor", () => {
    assert.ok(69.99 < SCORE_QUALIFY);
    assert.ok(70 >= SCORE_QUALIFY);
  });
});
