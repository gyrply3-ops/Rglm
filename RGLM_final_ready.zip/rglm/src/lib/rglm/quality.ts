/**
 * Data-quality engine. A security that fails validation cannot participate in RGLM.
 * Never guess; never repair corrupted bars.
 */

import {
  IMPOSSIBLE_ABS_LOG_RETURN,
  MIN_HISTORY_BARS,
  STALE_CALENDAR_DAYS,
  SUSPICIOUS_GAP_CALENDAR_DAYS,
} from "./constants.ts";
import type { DailyBar } from "./types.ts";
import { isFiniteNumber } from "./indicators.ts";

export type QualityIssue = {
  code:
    | "INSUFFICIENT_HISTORY"
    | "DUPLICATE_DATES"
    | "UNSORTED_DATES"
    | "INVALID_TIMESTAMP"
    | "NON_POSITIVE_PRICE"
    | "HIGH_LT_LOW"
    | "CLOSE_OUTSIDE_RANGE"
    | "OPEN_OUTSIDE_RANGE"
    | "MISSING_VOLUME"
    | "IMPOSSIBLE_RETURN"
    | "STALE_DATA"
    | "SUSPICIOUS_GAP"
    | "CORRUPTED_DATA";
  message: string;
};

export type QualityResult = {
  ok: boolean;
  issues: QualityIssue[];
  barCount: number;
};

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function calendarDaysBetween(a: string, b: string): number {
  const ms = Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`);
  if (!Number.isFinite(ms)) return NaN;
  return ms / 86_400_000;
}

export function validateRGLMData(
  bars: readonly DailyBar[],
  expectedSession: string | null,
  minBars = MIN_HISTORY_BARS,
): QualityResult {
  const issues: QualityIssue[] = [];
  if (!Array.isArray(bars) || bars.length === 0) {
    return {
      ok: false,
      issues: [{ code: "INSUFFICIENT_HISTORY", message: "No bars supplied." }],
      barCount: 0,
    };
  }

  if (bars.length < minBars) {
    issues.push({
      code: "INSUFFICIENT_HISTORY",
      message: `Only ${bars.length} sessions; ${minBars} required.`,
    });
  }

  const seen = new Set<string>();
  let prevDate: string | null = null;

  for (let i = 0; i < bars.length; i++) {
    const b = bars[i]!;
    if (!b || !DATE_RE.test(b.date) || !Number.isFinite(Date.parse(`${b.date}T00:00:00Z`))) {
      issues.push({
        code: "INVALID_TIMESTAMP",
        message: `Invalid date at index ${i}.`,
      });
      continue;
    }
    if (seen.has(b.date)) {
      issues.push({
        code: "DUPLICATE_DATES",
        message: `Duplicate session ${b.date}.`,
      });
    }
    seen.add(b.date);
    if (prevDate && b.date < prevDate) {
      issues.push({
        code: "UNSORTED_DATES",
        message: `Dates not ascending at ${b.date}.`,
      });
    }
    if (prevDate) {
      const gap = calendarDaysBetween(prevDate, b.date);
      if (isFiniteNumber(gap) && gap > SUSPICIOUS_GAP_CALENDAR_DAYS) {
        issues.push({
          code: "SUSPICIOUS_GAP",
          message: `${gap} calendar days between ${prevDate} and ${b.date}.`,
        });
      }
    }
    prevDate = b.date;

    const fields = [b.open, b.high, b.low, b.close];
    if (fields.some((v) => !isFiniteNumber(v))) {
      issues.push({
        code: "CORRUPTED_DATA",
        message: `Non-finite OHLC on ${b.date}.`,
      });
      continue;
    }
    if (fields.some((v) => v <= 0)) {
      issues.push({
        code: "NON_POSITIVE_PRICE",
        message: `Non-positive price on ${b.date}.`,
      });
    }
    if (b.high < b.low) {
      issues.push({ code: "HIGH_LT_LOW", message: `High < Low on ${b.date}.` });
    }
    if (b.close > b.high + 1e-12 || b.close < b.low - 1e-12) {
      issues.push({
        code: "CLOSE_OUTSIDE_RANGE",
        message: `Close outside high/low on ${b.date}.`,
      });
    }
    if (b.open > b.high + 1e-12 || b.open < b.low - 1e-12) {
      issues.push({
        code: "OPEN_OUTSIDE_RANGE",
        message: `Open outside high/low on ${b.date}.`,
      });
    }
    if (!isFiniteNumber(b.volume) || b.volume < 0) {
      issues.push({
        code: "MISSING_VOLUME",
        message: `Missing or invalid volume on ${b.date}.`,
      });
    }
    if (i > 0) {
      const prev = bars[i - 1]!;
      if (prev.close > 0 && isFiniteNumber(prev.close) && isFiniteNumber(b.close)) {
        const lr = Math.log(b.close / prev.close);
        if (isFiniteNumber(lr) && Math.abs(lr) > IMPOSSIBLE_ABS_LOG_RETURN) {
          issues.push({
            code: "IMPOSSIBLE_RETURN",
            message: `Impossible log-return on ${b.date}.`,
          });
        }
      }
    }
  }

  const last = bars[bars.length - 1];
  if (last && expectedSession) {
    const stale = calendarDaysBetween(last.date, expectedSession);
    if (isFiniteNumber(stale) && stale > STALE_CALENDAR_DAYS) {
      issues.push({
        code: "STALE_DATA",
        message: `Last bar ${last.date} is ${stale} days before session ${expectedSession}.`,
      });
    }
  }

  return { ok: issues.length === 0, issues, barCount: bars.length };
}
