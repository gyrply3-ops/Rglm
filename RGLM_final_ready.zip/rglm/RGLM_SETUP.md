# RGLM v0.1 — setup and verification

## Required secret

Set the server-side environment variable:

`EODHD_API_TOKEN`

Do not place the real token in source code, the browser bundle, screenshots, logs, or this repository.

Optional:

`XAI_API_KEY`

This enables the Explain panel. The AI layer only explains an already-calculated RGLM result and never changes the mathematical decision.

## Live-mode behavior

Without `EODHD_API_TOKEN`, the app must return `NO_TRADE` with `API_NOT_CONFIGURED` rather than using synthetic data for a live scan.

The Demo button is intentionally separate and is always labeled synthetic/demo data.

## Current-data provider

RGLM uses EODHD for daily OHLCV, exchange listings, and index constituents. The provider is server-only and reads the token through the environment.

## Production coverage

The production scanner counts unique eligible U.S. common-stock tickers. If fewer than 3,000 validated securities with sufficient daily history are available, the result is `INSUFFICIENT MARKET COVERAGE` / `NO_TRADE`.

The first successful live scans may therefore spend time warming the server-side cache. The app must never report 3,000+ scanned securities unless that coverage was actually validated.
