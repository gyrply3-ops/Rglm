import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

if (existsSync('node_modules/.package-lock.json') || existsSync('node_modules/vite')) {
  process.exit(0);
}

console.log('RGLM: node_modules not found; installing locked dependencies with npm ci...');
const result = spawnSync('npm', ['ci', '--no-audit', '--no-fund'], { stdio: 'inherit' });
if (result.error) {
  console.error(`RGLM: unable to start dependency installation: ${result.error.message}`);
  process.exit(1);
}
if (result.status !== 0) {
  console.error('RGLM: dependency installation failed. Check network access to registry.npmjs.org and try again.');
  process.exit(result.status ?? 1);
}
